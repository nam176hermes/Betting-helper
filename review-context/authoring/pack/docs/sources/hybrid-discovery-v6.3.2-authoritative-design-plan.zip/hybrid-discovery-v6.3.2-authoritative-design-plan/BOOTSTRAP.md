# Exact BOOT0 Procedure

The plan archive and sidecar must first be placed at:

```text
/home/thenam176/betting-helper/inputs/hybrid-discovery-v6.3.2-authoritative-design-plan.zip
/home/thenam176/betting-helper/inputs/hybrid-discovery-v6.3.2-authoritative-design-plan.zip.sha256
```

Execute these commands exactly:

```bash
mkdir -p /home/thenam176/betting-helper/inputs /home/thenam176/betting-helper/plan-input
cd /home/thenam176/betting-helper/inputs
sha256sum -c hybrid-discovery-v6.3.2-authoritative-design-plan.zip.sha256
python3.12 -m zipfile -e hybrid-discovery-v6.3.2-authoritative-design-plan.zip /home/thenam176/betting-helper/plan-input
cd /home/thenam176/betting-helper/plan-input/hybrid-discovery-v6.3.2-authoritative-design-plan
python3.12 bootstrap/verify_extracted_plan.py   --root /home/thenam176/betting-helper/plan-input/hybrid-discovery-v6.3.2-authoritative-design-plan   --receipt /home/thenam176/betting-helper/plan-input/.receipts/hybrid-discovery-v6.3.2-plan-input.json
python3.12 bootstrap/create_authoring_workspace.py   --plan-root /home/thenam176/betting-helper/plan-input/hybrid-discovery-v6.3.2-authoritative-design-plan   --authoring-root /home/thenam176/betting-helper/hybrid-discovery-v6.3.2-authoring   --receipt /home/thenam176/betting-helper/hybrid-discovery-v6.3.2-authoring/.bootstrap/authoring-workspace-receipt.json
python3.12 /home/thenam176/betting-helper/plan-input/hybrid-discovery-v6.3.2-authoritative-design-plan/bootstrap/initialize_authoring_repository.py   --root /home/thenam176/betting-helper/hybrid-discovery-v6.3.2-authoring   --receipt /home/thenam176/betting-helper/hybrid-discovery-v6.3.2-authoring/.bootstrap/authoring-repository-receipt.json
```

BOOT0 creates only the authoring workspace and its initial Git history. It performs no authenticated discovery, no provider call, and no production work.
