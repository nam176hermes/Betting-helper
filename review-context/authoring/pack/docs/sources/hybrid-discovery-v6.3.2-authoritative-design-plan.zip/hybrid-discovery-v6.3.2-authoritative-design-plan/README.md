# Hybrid Discovery v6.3.2 — Authoritative Design and Implementation Plan

This package is the assistant-authored, decision-complete repair of the rejected v6.3.1 plan. It retains the Hybrid product direction but authorizes no product or live-discovery work.

## Exact execution lifecycle

```text
BOOT0  verify/extract plan and create authoring Git workspace
  ↓
P00    freeze source, graphs, tasks, ownership; issue DECLARATION_COMPLETE
  ↓
MIG0   migrate/rebind v6.2 successor and issue migration receipt
  ↓
P01    materialize all source/test/config/review/release/harness artifacts
  ↓
P02    validate materialized contracts
  ↓
P03/P04/P05 durability + clock + review/security tooling
  ↓
P06    resolve every executable reference
  ↓
P07    candidate qualification
  ↓
P08    delivered zero-parent baseline
  ↓
P09    acyclic sealing
  ↓
P10    isolated Review A + Review B + deterministic aggregation
```

## Exact roots

```text
Plan ZIP input:      /home/thenam176/betting-helper/inputs/hybrid-discovery-v6.3.2-authoritative-design-plan.zip
Extracted plan:      /home/thenam176/betting-helper/plan-input/hybrid-discovery-v6.3.2-authoritative-design-plan
Authoring repository:/home/thenam176/betting-helper/hybrid-discovery-v6.3.2-authoring
Runtime candidate:   /home/thenam176/betting-helper/hybrid-discovery-v6.3.2-authoring/runtime
Pack candidate:      /home/thenam176/betting-helper/hybrid-discovery-v6.3.2-authoring/pack
Final runtime:       /home/thenam176/betting-helper/discovery-runtime-v6.3.2
Final pack:          /home/thenam176/betting-helper/review-packs/hybrid-discovery-v6.3.2
Review outputs:      /home/thenam176/betting-helper/reviews/hybrid-discovery-v6.3.2
```

## Frozen completeness additions

- All 46 inherited v6.2 crash cases are copied byte-for-byte and mapped exactly once to a process harness, child command, checkpoint, expected state, owner and verification command.
- All 65 named inherited clock/coherence vectors, including all 16 mapping negatives, are copied and accounted for.
- Declaration, materialization and executable-reference gates are distinct.
- The plan includes an exact bootstrap path; no command assumes a nonexistent authoring root.
- Review/release/aggregation tooling is materialized before qualification/export/review.
- Final ZIP identity is bound only by an external seal attestation, avoiding self-reference.

```text
PLAN_CONTRACT_COMPLETE:             pending independent review
TASKS_EXECUTABLE_BY_FRESH_CODEX:    pending independent review
FINDING_COVERAGE_COMPLETE:          pending independent review
SECURITY_REVIEW_CONTRACT_COMPLETE:  pending independent review
AUTHORIZED_PRODUCTION_PHASES:       NONE
```
