# Hybrid Discovery v6.3.2 — Master Implementation Plan

## Current authority

```text
PLAN_AUTHORED:                      YES
READY_FOR_INDEPENDENT_PLAN_REVIEW: YES
READY_TO_IMPLEMENT:                NO
AUTHORIZED_PRODUCTION_PHASES:      NONE
```

## Inventory

- Phases: **13**
- Tasks: **59**
- Registered exact commands: **109**
- Inherited crash vectors: **46 / 46 mapped**
- Inherited clock/coherence vector IDs: **65 accounted**

## Execution order

```text
BOOT0
  ↓
P00 → MIG0 → P01 → P02
                     ├── P03 durability
                     ├── P04 clock
                     └── P05 review/security/release tooling
                              ↓
                             P06
                              ↓
                             P07
                              ↓
                             P08
                              ↓
                             P09
                       ┌──────┴──────┐
                       ▼             ▼
                    Review A      Review B
                       └──────┬──────┘
                              ▼
                             P10
```

## Checkpoints

1. **BOOT0:** authoring root and Git history actually exist before task commands use them.
2. **Declaration:** every artifact has one source/owner and consumers follow owners; symbols need not yet exist.
3. **Migration:** all active v6.2 roots/IDs/vendor/registry references are rebound by MIG0 only.
4. **Materialization:** all planned files/stubs/configs/review/release/harness entrypoints exist and compile.
5. **Durability:** all 46 inherited vectors are process-executed, restart-inspected and mutation-sensitive.
6. **Clock:** all 65 named vectors are accounted; 16 mapping negatives are recomputed in Python and TypeScript.
7. **Executable exactness:** every exact path, symbol, schema pointer, vector, config and command resolves.
8. **Qualification:** no proof is accepted from prose or declaration-only vectors.
9. **Export:** the delivered runtime is generated only after all release/review tooling is part of the qualified candidate.
10. **Seal:** no internal artifact self-references the final ZIP identity.
11. **Review:** both reviews are complete; a skipped cybersecurity area is HOLD.

## Implementation discipline

One task, one focused commit, one task-evidence record, then stop. No task may run authenticated discovery, provider I/O, product logic or production work.
