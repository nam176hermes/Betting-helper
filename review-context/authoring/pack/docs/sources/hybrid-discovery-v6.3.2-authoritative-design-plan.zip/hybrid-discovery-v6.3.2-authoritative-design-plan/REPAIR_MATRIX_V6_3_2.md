# v6.3.1 → v6.3.2 Repair Matrix

| Finding | Repair | Mechanical acceptance |
|---|---|---|
| Circular self-review | Governed root plus external final attestation | No internal final-ZIP hash dependency |
| Materialization conflicts | BOOT0 and separate declaration/materialization/executable gates | No gate consumes a later-owned artifact |
| Migration owner missing | MIG0 owns sync, rebinding, registry generation and legacy scan | Active legacy references zero |
| Non-exact references | Ownership registry, exact JSON pointers, exact commands and late executable resolver | No placeholder, invalid pointer, unowned artifact or unresolved symbol |
| Incomplete verification | Full 46-case crash registry, 65-ID clock coverage, fixed test configs and proof matrix | Declared equals executed; no vector skipped |
| Cybersecurity aggregation | Exact security command registry and host-issued isolated dual reviews | Skipped area equals HOLD; independence receipts required |
| Authoring-root precondition | BOOT0 exact extraction/workspace/Git procedure | P00 never runs in a nonexistent root |
