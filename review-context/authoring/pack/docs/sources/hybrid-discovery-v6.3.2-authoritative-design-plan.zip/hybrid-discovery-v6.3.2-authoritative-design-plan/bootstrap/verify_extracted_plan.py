from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path

def verify_extracted_plan(root: Path, receipt: Path) -> dict:
    manifest_path = root / "MANIFEST_SHA256.json"
    if not manifest_path.is_file():
        raise SystemExit("E_BOOT0_MANIFEST_MISSING")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    for item in manifest["entries"]:
        p = root / item["path"]
        if not p.is_file(): raise SystemExit("E_BOOT0_FILE_MISSING:" + item["path"])
        if len(p.read_bytes()) != item["size"]: raise SystemExit("E_BOOT0_SIZE_MISMATCH:" + item["path"])
        if hashlib.sha256(p.read_bytes()).hexdigest() != item["sha256"]:
            raise SystemExit("E_BOOT0_HASH_MISMATCH:" + item["path"])
    result={"schema_version":"boot0-plan-input-receipt/v1","root":str(root),"manifest_sha256":hashlib.sha256(manifest_path.read_bytes()).hexdigest(),"verified_entries":len(manifest["entries"])}
    receipt.parent.mkdir(parents=True,exist_ok=True)
    receipt.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    return result

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",required=True); ap.add_argument("--receipt",required=True)
    a=ap.parse_args(); verify_extracted_plan(Path(a.root),Path(a.receipt))
if __name__=="__main__": main()
