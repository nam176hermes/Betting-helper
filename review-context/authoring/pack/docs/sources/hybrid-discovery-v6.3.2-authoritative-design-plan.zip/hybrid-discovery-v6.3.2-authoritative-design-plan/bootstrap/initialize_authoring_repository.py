from __future__ import annotations
import argparse, json, subprocess
from pathlib import Path

def run(*argv: str, cwd: Path) -> str:
    return subprocess.check_output(argv,cwd=cwd,text=True).strip()

def initialize(root: Path, receipt: Path) -> dict:
    if (root/".git").exists(): raise SystemExit("E_BOOT0_GIT_ALREADY_EXISTS")
    subprocess.check_call(["git","init","-b","main"],cwd=root)
    subprocess.check_call(["git","config","user.name","Hybrid Discovery Author"],cwd=root)
    subprocess.check_call(["git","config","user.email","hybrid-discovery@local.invalid"],cwd=root)
    subprocess.check_call(["git","add","."],cwd=root)
    subprocess.check_call(["git","commit","-m","chore: initialize v6.3.2 authoring workspace"],cwd=root)
    if run("git","remote",cwd=root): raise SystemExit("E_BOOT0_REMOTE_PRESENT")
    result={"schema_version":"boot0-authoring-repository-receipt/v1","root":str(root),"head":run("git","rev-parse","HEAD",cwd=root),"tree":run("git","rev-parse","HEAD^{tree}",cwd=root),"status":run("git","status","--porcelain=v1",cwd=root)}
    receipt.parent.mkdir(parents=True,exist_ok=True); receipt.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    return result

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",required=True); ap.add_argument("--receipt",required=True)
    a=ap.parse_args(); initialize(Path(a.root),Path(a.receipt))
if __name__=="__main__": main()
