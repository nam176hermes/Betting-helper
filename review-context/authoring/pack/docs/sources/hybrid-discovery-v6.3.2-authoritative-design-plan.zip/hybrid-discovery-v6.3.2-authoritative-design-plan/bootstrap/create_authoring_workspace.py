from __future__ import annotations
import argparse, hashlib, json, shutil
from pathlib import Path

def tree_root(root: Path) -> str:
    h=hashlib.sha256()
    for p in sorted(x for x in root.rglob("*") if x.is_file() and ".git" not in x.parts):
        rel=p.relative_to(root).as_posix().encode(); b=p.read_bytes()
        h.update(len(rel).to_bytes(4,"big")); h.update(rel); h.update(hashlib.sha256(b).digest())
    return h.hexdigest()

def create_authoring_workspace(plan_root: Path, authoring_root: Path, receipt: Path) -> dict:
    if authoring_root.exists(): raise SystemExit("E_BOOT0_AUTHORING_ROOT_EXISTS")
    authoring_root.mkdir(parents=True)
    for name in ["runtime","pack","authoring-tools","authoring-tests",".bootstrap"]:
        (authoring_root/name).mkdir(parents=True,exist_ok=True)
    dst=authoring_root/"plan-input"
    shutil.copytree(plan_root,dst,ignore=shutil.ignore_patterns(".bootstrap"))
    result={"schema_version":"boot0-authoring-workspace-receipt/v1","plan_input_root":str(dst),"authoring_root":str(authoring_root),"plan_input_tree_root":tree_root(dst)}
    receipt.parent.mkdir(parents=True,exist_ok=True); receipt.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    return result

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--plan-root",required=True); ap.add_argument("--authoring-root",required=True); ap.add_argument("--receipt",required=True)
    a=ap.parse_args(); create_authoring_workspace(Path(a.plan_root),Path(a.authoring_root),Path(a.receipt))
if __name__=="__main__": main()
