# Hybrid Discovery v6.3.2 — Corrected Design

## 1. Scope

This is a contract-hardening and discovery-implementation plan. It does not redesign the Hybrid product and does not authorize authenticated Mise-o-jeu access, provider calls, WDL, market pricing, Paper, Real Money, Cashout, or Hermes.

## 2. Artifact topology

```text
sealed plan input
   ↓ BOOT0
normal-history authoring repository
   ├── runtime candidate
   ├── pack candidate
   ├── authoring tools/tests
   └── immutable plan input
   ↓ qualification
zero-parent delivered runtime
   ↓
sealed review pack
   ├── Review A isolated workspace
   └── Review B isolated workspace
   ↓
deterministic aggregate verdict
```

## 3. Lifecycle and gates

| Lifecycle | Meaning | Gate |
|---|---|---|
| `DECLARED` | Owner, exact path, command/schema/vector identity and predecessor are frozen | `DECLARATION_COMPLETE` |
| `MATERIALIZED` | Files, stubs, configs, tools and harnesses exist and compile | `MATERIALIZATION_COMPLETE` |
| `MATERIALIZED` | Materialized contracts additionally pass task/ownership semantic validation | `MATERIALIZED_CONTRACTS_VALID` |
| `EXECUTABLE` | Every exact file/symbol/schema/vector/command resolves | `EXECUTABLE_REFERENCE_COMPLETE` |
| `QUALIFIED` | Every proof-matrix row has current executed evidence | `CANDIDATE_QUALIFICATION_ACCEPTED` |
| `SEALED` | Zero-parent baseline and pack are immutable and externally attested | `PACK_SEALED` |
| `EXTERNAL_REVIEWED` | Separate implementation and cybersecurity reviews are finalized | `AGGREGATE_REVIEW_COMPLETE` |

A later gate never supplies an input to an earlier gate.

## 4. Acyclic sealing

```text
Governed content → governed root → internal self-review → manifest → ZIP → external attestation
```

The internal self-review binds no final ZIP or manifest hash. The external attestation binds ZIP, manifest, governed root, self-review, task manifest and REPO0 receipt.

## 5. Complete inherited verification inventory

The v6.2 durability and clock vector files are bundled as immutable source evidence. The crash registry maps all 46 case IDs; the clock coverage registry accounts for all 65 named IDs. The implementation may create successor vectors only through an explicit, reviewed amendment and may not silently reduce inherited coverage.

## 6. Review isolation

Review A and Review B use host-issued one-use launch authorizations, separate roles, serials, workspaces and output roots, identical read-only inputs, no authoring mount and no peer-output mount. Exact review commands are frozen before the delivered baseline is exported. Fresh model-session context remains a procedural human attestation, not a cryptographic claim.

## 7. Target review state

```text
PLAN_CONTRACT_COMPLETE:             YES
TASKS_EXECUTABLE_BY_FRESH_CODEX:    YES
FINDING_COVERAGE_COMPLETE:          YES
SECURITY_REVIEW_CONTRACT_COMPLETE:  YES
AUTHORIZED_PRODUCTION_PHASES:       NONE
```

These verdicts approve only authoring/implementation of the discovery successor; an authenticated discovery run still requires separate one-use authorization.
