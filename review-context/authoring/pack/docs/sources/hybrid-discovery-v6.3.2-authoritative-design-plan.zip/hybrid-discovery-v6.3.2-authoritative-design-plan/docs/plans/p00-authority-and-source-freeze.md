# P00 — Authority and source freeze

**Tasks:** 5

## Phase gate

`DECLARATION_COMPLETE`

## V632-P00-T01 — Freeze source reviews and provenance

### Objective

Import the v6.3.1 plan review as immutable source evidence and bind the v6.3.1 plan ZIP plus v6.2 review hashes.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C1, V631-C2, V631-C3, V631-C4, V631-C5, V631-C6

### Dependencies

- `V632-BOOT0-T03`

### Exact files

- `authoring-tools/import_review_sources.py`
- `authoring-tests/test_review_source_import.py`
- `pack/docs/reviews/v6.3.1-plan-review-input.md`
- `pack/docs/receipts/source-provenance.v1.json`
- `pack/docs/registries/source-inputs.v1.json`

### Exact symbols

- `authoring-tools/import_review_sources.py::import_review_sources`
- `authoring-tests/test_review_source_import.py::test_review_sources_match_frozen_hashes`

### Exact schema references

- `pack/docs/schemas/migration-receipt.schema.json#/$defs/MigrationReceipt`

### Exact command IDs

- `VERIFY_V632_P00_T01`

### Tests first

- `authoring-tests/test_review_source_import.py`

### Positive vectors

- `V632-P00-T01-POS-01`

### Negative vectors

- `V632-P00-T01-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- Source hashes exactly match the frozen registry
- Imported review bytes are immutable
- No source review is rewritten

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P00-T01.json`

### Rollback

- Revert only commit for V632-P00-T01
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p00): freeze source reviews and provenance`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P00-T02 — Freeze authority graphs

### Objective

Create separate machine-readable executable and future graphs with no cross-class edge or reachability.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C2

### Dependencies

- `V632-P00-T01`

### Exact files

- `authoring-tools/validate_authority_graph.py`
- `authoring-tests/test_authority_graph.py`
- `pack/docs/graphs/executable-discovery-graph.v1.json`
- `pack/docs/graphs/non-authoritative-future-roadmap.v1.json`
- `pack/docs/contracts/02-authority-graph.md`

### Exact symbols

- `authoring-tools/validate_authority_graph.py::validate_graph_partition`
- `authoring-tests/test_authority_graph.py::test_executable_and_future_graphs_are_disconnected`

### Exact schema references


### Exact command IDs

- `VERIFY_V632_P00_T02`

### Tests first

- `authoring-tests/test_authority_graph.py`

### Positive vectors

- `V632-P00-T02-POS-01`

### Negative vectors

- `V632-P00-T02-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- No cross-set endpoints
- No executable-to-future transitive path
- AUTHORIZED_PRODUCTION_PHASES remains NONE

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P00-T02.json`

### Rollback

- Revert only commit for V632-P00-T02
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p00): freeze authority graphs`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P00-T03 — Freeze task schema and manifest semantics

### Objective

Define the exact task-card format, task lifecycle, dependency semantics, authority enum, and semantic validator responsibilities.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C2, V631-C4

### Dependencies

- `V632-P00-T02`

### Exact files

- `authoring-tools/validate_task_manifest.py`
- `authoring-tests/test_task_manifest_semantics.py`
- `pack/docs/tasks/task-manifest.v6.3.2.json`
- `pack/docs/schemas/task-card-v6.3.2.schema.json`
- `pack/docs/contracts/01-artifact-lifecycle.md`

### Exact symbols

- `authoring-tools/validate_task_manifest.py::validate_task_manifest_semantics`
- `authoring-tests/test_task_manifest_semantics.py::test_task_manifest_rejects_placeholders_unknown_dependencies_and_production_authority`

### Exact schema references

- `pack/docs/schemas/task-card-v6.3.2.schema.json#/$defs/TaskManifestV632`
- `pack/docs/schemas/task-card-v6.3.2.schema.json#/$defs/TaskCardV632`

### Exact command IDs

- `VERIFY_V632_P00_T03`

### Tests first

- `authoring-tests/test_task_manifest_semantics.py`

### Positive vectors

- `V632-P00-T03-POS-01`

### Negative vectors

- `TASK-AUTHORITY-PRODUCTION`
- `TASK-COMMAND-PLACEHOLDER`
- `TASK-UNKNOWN-DEPENDENCY`
- `TASK-EMPTY-ROLLBACK`
- `TASK-COUNT-MISMATCH`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- Task count equals array length
- Only approved task authorities are accepted
- Every dependency names an earlier declared task

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P00-T03.json`

### Rollback

- Revert only commit for V632-P00-T03
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p00): freeze task schema and manifest semantics`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P00-T04 — Freeze artifact ownership and path registries

### Objective

Assign every planned artifact one creation owner, lifecycle stage, and allowed modifier set.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C2, V631-C4

### Dependencies

- `V632-P00-T03`

### Exact files

- `authoring-tools/validate_artifact_ownership.py`
- `authoring-tests/test_artifact_ownership.py`
- `pack/docs/registries/artifact-ownership.v1.json`
- `pack/docs/registries/path-registry.v1.json`
- `pack/docs/registries/schema-reference-registry.v1.json`
- `pack/docs/schemas/artifact-ownership.schema.json`

### Exact symbols

- `authoring-tools/validate_artifact_ownership.py::validate_artifact_ownership`
- `authoring-tests/test_artifact_ownership.py::test_every_referenced_artifact_has_one_creation_owner`

### Exact schema references

- `pack/docs/schemas/artifact-ownership.schema.json#/$defs/ArtifactOwnershipRegistry`

### Exact command IDs

- `VERIFY_V632_P00_T04`

### Tests first

- `authoring-tests/test_artifact_ownership.py`

### Positive vectors

- `V632-P00-T04-POS-01`

### Negative vectors

- `V632-P00-T04-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- Every exact file has a baseline source or one creation owner
- No artifact has conflicting creation owners
- Consumers never precede creation owner

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P00-T04.json`

### Rollback

- Revert only commit for V632-P00-T04
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p00): freeze artifact ownership and path registries`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P00-T05 — Issue DECLARATION_COMPLETE gate

### Objective

Prove that every planned artifact, command, schema, vector, task dependency, lifecycle stage, and authority class is declared and owned without requiring future implementation symbols to exist.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → DECLARED`

### Findings

V631-C2, V631-C4

### Dependencies

- `V632-P00-T04`

### Exact files

- `authoring-tools/issue_declaration_gate.py`
- `authoring-tests/test_declaration_gate.py`
- `pack/docs/receipts/declaration-complete.v1.json`

### Exact symbols

- `authoring-tools/issue_declaration_gate.py::issue_declaration_complete_receipt`
- `authoring-tests/test_declaration_gate.py::test_declaration_gate_checks_ownership_without_requiring_materialized_symbols`

### Exact schema references


### Exact command IDs

- `ISSUE_V632_P00_T05`

### Tests first

- `authoring-tests/test_declaration_gate.py`

### Positive vectors

- `DECLARATION-ALL-OWNED-AND-ORDERED`

### Negative vectors

- `DECLARATION-UNOWNED-ARTIFACT`
- `DECLARATION-CONSUMER-BEFORE-OWNER`
- `DECLARATION-REQUIRES-FUTURE-SYMBOL`

### Implementation steps

- Run the failing exact test or precondition command and record the intended failure.
- Implement only the named files and symbols.
- Run every exact command ID and inspect the diff.
- Write the task evidence record, commit once, and stop.

### Acceptance criteria

- Every planned artifact has exactly one baseline source or creation owner
- No consumer precedes its owner
- No materialization or symbol-existence proof is required at declaration stage

### Failure states

- `INPUT_INTEGRITY_FAILED`
- `DECLARED_ARTIFACT_MISSING`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P00-T05.json`

### Rollback

- Revert the single commit for V632-P00-T05
- Restore the last accepted task-evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football-provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p00): issue declaration_complete gate`

### Stop condition

Stop if any exact input, file, symbol, schema, vector, command, or authority condition is unresolved.
