# Command and Configuration Lifecycle

All review, release, export, aggregation, crash and clock tooling is materialized before P06. Each command has a stable ID, exact cwd, argv array, expected exit, network policy and access policy. Configuration files are owned artifacts. Command registration cannot point to a prompt or unresolved path.
