# P02 — Materialized contract validation

**Tasks:** 3

## Phase gate

`MATERIALIZED_CONTRACTS_VALID`

## V632-P02-T01 — Validate materialized task-manifest semantics

### Objective

Reject task-count mismatch, unknown/forward dependencies, production authority, placeholders, empty rollback, unresolved command IDs, and invalid lifecycle transitions.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C4

### Dependencies

- `V632-P01-T06`

### Exact files

- `runtime/src/moj_discovery/task_contracts.py`
- `runtime/tests/contracts/test_task_manifest_semantics.py`

### Exact symbols

- `runtime/src/moj_discovery/task_contracts.py::validate_task_manifest_semantics`
- `runtime/tests/contracts/test_task_manifest_semantics.py::test_review_counterexamples_are_rejected`

### Exact schema references

- `pack/docs/schemas/task-card-v6.3.2.schema.json#/$defs/TaskManifestV632`
- `pack/docs/schemas/task-card-v6.3.2.schema.json#/$defs/TaskCardV632`

### Exact command IDs

- `TEST_V632_P02_T01`

### Tests first

- `runtime/tests/contracts/test_task_manifest_semantics.py`

### Positive vectors

- `V632-P02-T01-POS-01`

### Negative vectors

- `TASK-PRODUCTION-AUTHORITY`
- `TASK-PLACEHOLDER-COMMAND`
- `TASK-UNKNOWN-DEPENDENCY`
- `TASK-FUTURE-DEPENDENCY`
- `TASK-EMPTY-ROLLBACK`
- `TASK-COUNT-MISMATCH`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P02-T01.json`

### Rollback

- Revert only commit for V632-P02-T01
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p02): implement task-manifest semantic validation`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P02-T02 — Validate materialized artifact ownership and lifecycle

### Objective

Validate owner uniqueness, owner-before-consumer ordering, declared materialization stage, modifier permissions, and no unowned required artifact.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C2, V631-C4

### Dependencies

- `V632-P02-T01`

### Exact files

- `runtime/src/moj_discovery/artifact_ownership.py`
- `runtime/tests/contracts/test_artifact_dependency_semantics.py`

### Exact symbols

- `runtime/src/moj_discovery/artifact_ownership.py::validate_artifact_lifecycle`
- `runtime/tests/contracts/test_artifact_dependency_semantics.py::test_consumer_cannot_precede_creation_owner`

### Exact schema references

- `pack/docs/schemas/artifact-ownership.schema.json#/$defs/ArtifactOwnershipRegistry`

### Exact command IDs

- `TEST_V632_P02_T02`

### Tests first

- `runtime/tests/contracts/test_artifact_dependency_semantics.py`

### Positive vectors

- `V632-P02-T02-POS-01`

### Negative vectors

- `V632-P02-T02-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P02-T02.json`

### Rollback

- Revert only commit for V632-P02-T02
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p02): implement artifact ownership and lifecycle validation`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P02-T03 — Issue MATERIALIZED_CONTRACTS_VALID gate

### Objective

Prove the plan has complete ownership, exact command identities, valid schema references, and no unresolved declaration-level architecture.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C2, V631-C4

### Dependencies

- `V632-P02-T02`

### Exact files

- `runtime/src/moj_discovery/declaration_gate.py`
- `runtime/tests/contracts/test_declaration_complete_gate.py`

### Exact symbols

- `runtime/src/moj_discovery/declaration_gate.py::issue_declaration_complete_receipt`
- `runtime/tests/contracts/test_declaration_complete_gate.py::test_declaration_gate_fails_on_unowned_schema_or_command`

### Exact schema references


### Exact command IDs

- `TEST_V632_P02_T03`

### Tests first

- `runtime/tests/contracts/test_declaration_complete_gate.py`

### Positive vectors

- `V632-P02-T03-POS-01`

### Negative vectors

- `V632-P02-T03-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- Every planned artifact has an owner
- Every command ID exists
- Schema refs may be declared only when their materialization owner is complete

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P02-T03.json`

### Rollback

- Revert only commit for V632-P02-T03
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p02): issue declaration_complete gate`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.
