# MIG0 — Successor migration and rebinding

**Tasks:** 6

## Phase gate

`MIGRATION_COMPLETE`

## V632-MIG0-T01 — Verify v6.2 source baseline

### Objective

Verify the immutable source runtime, receipts, locks, tree root, clean state, and absence of remotes before migration.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C3

### Dependencies

- `V632-P00-T05`

### Exact files

- `authoring-tools/verify_v62_source.py`
- `authoring-tests/test_v62_source_identity.py`
- `pack/docs/registries/migration-source.v1.json`

### Exact symbols

- `authoring-tools/verify_v62_source.py::verify_v62_source`
- `authoring-tests/test_v62_source_identity.py::test_v62_source_matches_frozen_identity`

### Exact schema references


### Exact command IDs

- `VERIFY_V632_MIG0_T01`

### Tests first

- `authoring-tests/test_v62_source_identity.py`

### Positive vectors

- `V632-MIG0-T01-POS-01`

### Negative vectors

- `V632-MIG0-T01-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- Source HEAD/tree/root match receipt
- Source working tree is clean
- No remote exists

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-MIG0-T01.json`

### Rollback

- Revert only commit for V632-MIG0-T01
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(mig0): verify v6.2 source baseline`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-MIG0-T02 — Create successor authoring workspace

### Objective

Create the authoring Git repository with runtime, pack, tools, tests, and evidence roots without copying source Git metadata or evidence.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C3

### Dependencies

- `V632-MIG0-T01`

### Exact files

- `authoring-tools/create_successor_workspace.py`
- `authoring-tests/test_successor_workspace.py`

### Exact symbols

- `authoring-tools/create_successor_workspace.py::create_successor_workspace`
- `authoring-tests/test_successor_workspace.py::test_successor_copy_excludes_git_cache_local_and_evidence`

### Exact schema references


### Exact command IDs

- `VERIFY_V632_MIG0_T02`

### Tests first

- `authoring-tests/test_successor_workspace.py`

### Positive vectors

- `V632-MIG0-T02-POS-01`

### Negative vectors

- `V632-MIG0-T02-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- Destination roots are exact
- No source .git copied
- No live evidence copied
- Authoring repository has normal commit history

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-MIG0-T02.json`

### Rollback

- Revert only commit for V632-MIG0-T02
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(mig0): create successor authoring workspace`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-MIG0-T03 — Rebind versioned paths, IDs, and working roots

### Objective

Apply the closed v6.2-to-v6.3.2 rebinding table to runtime and pack candidates.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C3

### Dependencies

- `V632-MIG0-T02`

### Exact files

- `authoring-tools/rebind_successor.py`
- `authoring-tests/test_version_rebinding.py`
- `pack/docs/registries/version-rebinding.v1.json`
- `pack/docs/contracts/02-successor-migration-rebinding.md`

### Exact symbols

- `authoring-tools/rebind_successor.py::apply_rebinding_plan`
- `authoring-tests/test_version_rebinding.py::test_every_rebinding_is_declared_and_idempotent`

### Exact schema references


### Exact command IDs

- `VERIFY_V632_MIG0_T03`

### Tests first

- `authoring-tests/test_version_rebinding.py`

### Positive vectors

- `V632-MIG0-T03-POS-01`

### Negative vectors

- `V632-MIG0-T03-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- No undeclared textual replacement
- Rebinding is idempotent
- Historical provenance remains unchanged

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-MIG0-T03.json`

### Rollback

- Revert only commit for V632-MIG0-T03
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(mig0): rebind versioned paths, ids, and working roots`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-MIG0-T04 — Synchronize one normative bundle

### Objective

Make pack/docs the sole normative source and copy exact governed schemas, vectors, registries, contracts, and protocol locks into runtime/vendor.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C3, V631-C4

### Dependencies

- `V632-MIG0-T03`

### Exact files

- `authoring-tools/sync_normative_bundle.py`
- `authoring-tests/test_normative_sync.py`
- `runtime/tools/sync_pack_assets.py`
- `runtime/schema-lock.json`
- `runtime/vendor/hybrid-discovery-v6.3.2/SCHEMA_SHA256.json`

### Exact symbols

- `authoring-tools/sync_normative_bundle.py::synchronize_normative_bundle`
- `runtime/tools/sync_pack_assets.py::synchronize_normative_assets`
- `authoring-tests/test_normative_sync.py::test_runtime_vendor_bytes_equal_pack_normative_bytes`

### Exact schema references


### Exact command IDs

- `VERIFY_V632_MIG0_T04`

### Tests first

- `authoring-tests/test_normative_sync.py`

### Positive vectors

- `V632-MIG0-T04-POS-01`

### Negative vectors

- `V632-MIG0-T04-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- Pack is sole normative source
- Runtime vendor bytes match exactly
- Schema lock records every vendored file

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-MIG0-T04.json`

### Rollback

- Revert only commit for V632-MIG0-T04
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(mig0): synchronize one normative bundle`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-MIG0-T05 — Regenerate task command registry and config bindings

### Objective

Generate a successor-only exact command registry with no v6.2 working directories, command IDs, or placeholder arguments.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C3, V631-C4, V631-C5

### Dependencies

- `V632-MIG0-T04`

### Exact files

- `authoring-tools/build_task_command_registry.py`
- `authoring-tests/test_command_registry_generation.py`
- `runtime/task-command-registry.json`
- `runtime/review-config/review-a.v1.json`
- `runtime/review-config/review-b.v1.json`
- `runtime/review-config/review-aggregation.v1.json`

### Exact symbols

- `authoring-tools/build_task_command_registry.py::build_task_command_registry`
- `authoring-tests/test_command_registry_generation.py::test_registry_has_exact_successor_paths_and_no_placeholders`

### Exact schema references

- `pack/docs/schemas/command-registry.schema.json#/$defs/CommandRegistry`

### Exact command IDs

- `VERIFY_V632_MIG0_T05`

### Tests first

- `authoring-tests/test_command_registry_generation.py`

### Positive vectors

- `V632-MIG0-T05-POS-01`

### Negative vectors

- `V632-MIG0-T05-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- Every task command ID resolves
- No command contains placeholder syntax
- No command references v6.2 runtime

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-MIG0-T05.json`

### Rollback

- Revert only commit for V632-MIG0-T05
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(mig0): regenerate task command registry and config bindings`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-MIG0-T06 — Scan legacy references and issue migration receipt

### Objective

Prove all active paths, hashes, roots, registry IDs, and vendor destinations are rebound while historical references remain explicitly classified.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C3

### Dependencies

- `V632-MIG0-T05`

### Exact files

- `authoring-tools/verify_successor_migration.py`
- `authoring-tests/test_successor_migration_receipt.py`
- `pack/docs/receipts/migration-receipt.v1.json`

### Exact symbols

- `authoring-tools/verify_successor_migration.py::verify_successor_migration`
- `authoring-tests/test_successor_migration_receipt.py::test_migration_receipt_accounts_for_every_active_legacy_reference`

### Exact schema references

- `pack/docs/schemas/migration-receipt.schema.json#/$defs/MigrationReceipt`

### Exact command IDs

- `VERIFY_V632_MIG0_T06`

### Tests first

- `authoring-tests/test_successor_migration_receipt.py`

### Positive vectors

- `V632-MIG0-T06-POS-01`

### Negative vectors

- `V632-MIG0-T06-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- Active legacy references equal zero
- Historical references are registry-approved
- Migration receipt is content-addressed

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-MIG0-T06.json`

### Rollback

- Revert only commit for V632-MIG0-T06
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(mig0): scan legacy references and issue migration receipt`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.
