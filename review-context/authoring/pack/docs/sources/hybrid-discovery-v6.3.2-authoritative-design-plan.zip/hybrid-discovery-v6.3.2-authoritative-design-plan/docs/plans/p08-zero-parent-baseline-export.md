# P08 — Zero-parent baseline export

**Tasks:** 3

## Phase gate

`REPO0_BASELINE_VALID`

## V632-P08-T01 — Export deterministic final runtime candidate

### Objective

Export exact tracked candidate bytes and modes from accepted authoring HEAD into a clean destination without Git history, local evidence, caches, or pack source.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C2

### Dependencies

- `V632-P07-T03`

### Exact files

- `runtime/tools/export_zero_parent_candidate.py`
- `runtime/tests/release/test_zero_parent_export.py`

### Exact symbols

- `runtime/tools/export_zero_parent_candidate.py::export_zero_parent_candidate`
- `runtime/tests/release/test_zero_parent_export.py::test_export_contains_only_candidate_inventory_and_exact_modes`

### Exact schema references


### Exact command IDs

- `VERIFY_V632_P08_T01`

### Tests first

- `runtime/tests/release/test_zero_parent_export.py`

### Positive vectors

- `V632-P08-T01-POS-01`

### Negative vectors

- `V632-P08-T01-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P08-T01.json`

### Rollback

- Revert only commit for V632-P08-T01
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p08): export deterministic final runtime candidate`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P08-T02 — Create delivered zero-parent Git baseline

### Objective

Initialize the final runtime as a no-remote repository and create one zero-parent commit from exported bytes.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C2

### Dependencies

- `V632-P08-T01`

### Exact files

- `runtime/tools/create_zero_parent_repository.py`
- `runtime/tests/release/test_zero_parent_repository.py`

### Exact symbols

- `runtime/tools/create_zero_parent_repository.py::create_zero_parent_repository`
- `runtime/tests/release/test_zero_parent_repository.py::test_delivered_repository_has_one_zero_parent_commit_and_no_remote`

### Exact schema references


### Exact command IDs

- `VERIFY_V632_P08_T02`

### Tests first

- `runtime/tests/release/test_zero_parent_repository.py`

### Positive vectors

- `V632-P08-T02-POS-01`

### Negative vectors

- `V632-P08-T02-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P08-T02.json`

### Rollback

- Revert only commit for V632-P08-T02
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p08): create delivered zero-parent git baseline`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P08-T03 — Replay committed baseline in place and issue REPO0 receipt

### Objective

Run POST_COMMIT_BASELINE directly in the delivered Git repository and record actual commit/tree/file-root/toolchain/lock/vendor/command roots.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C2

### Dependencies

- `V632-P08-T02`

### Exact files

- `runtime/tools/qualify_zero_parent_baseline.py`
- `runtime/tests/release/test_post_commit_baseline.py`
- `pack/docs/receipts/repo0-baseline-receipt.json`

### Exact symbols

- `runtime/tools/qualify_zero_parent_baseline.py::qualify_zero_parent_baseline`
- `runtime/tests/release/test_post_commit_baseline.py::test_full_registry_replays_in_actual_committed_repository`

### Exact schema references


### Exact command IDs

- `VERIFY_V632_P08_T03`

### Tests first

- `runtime/tests/release/test_post_commit_baseline.py`

### Positive vectors

- `V632-P08-T03-POS-01`

### Negative vectors

- `V632-P08-T03-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- No temporary Git-less overlay
- Working tree clean
- HEAD/tree/file root and command root match receipt

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P08-T03.json`

### Rollback

- Revert only commit for V632-P08-T03
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p08): replay committed baseline in place and issue repo0 receipt`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.
