Implement Hybrid Discovery v6.3.2 task-by-task.

Read README.md, AGENTS.md, DESIGN_V6_3_2.md, IMPLEMENTATION_PLAN_V6_3_2.md and docs/tasks/task-manifest.v6.3.2.json.

You are authorized for `V632-P00-T01` only. Write the failing exact test first, implement only the named files and symbols, run only the registered exact commands, commit once, write the task evidence report, and stop. Do not run authenticated discovery, call providers, or implement production work.
