# Successor Migration and Rebinding Contract

MIG0 is the only phase allowed to copy v6.2 candidate bytes or change active version/path/URN/registry bindings. The version-rebinding registry contains exact old value, new value, file scope, replacement mode and historical exceptions. A legacy scan fails on any active v6.2 reference not classified as provenance or immutable review history.
