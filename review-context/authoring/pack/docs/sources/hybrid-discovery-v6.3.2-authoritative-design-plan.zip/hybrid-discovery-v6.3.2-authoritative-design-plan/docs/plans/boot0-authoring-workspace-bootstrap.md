# BOOT0 — Authoring workspace bootstrap

**Tasks:** 3

## Phase gate

`AUTHORING_WORKSPACE_READY`

## V632-BOOT0-T01 — Verify and extract sealed plan input

### Objective

Verify the supplied plan ZIP against its sidecar, safely extract it, and verify its self-excluding manifest before any authoring workspace is created.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C2, V631-C3

### Dependencies

- None

### Exact files

- `/home/thenam176/betting-helper/plan-input/.receipts/hybrid-discovery-v6.3.2-plan-input.json`

### Exact symbols

- `bootstrap/verify_extracted_plan.py::verify_extracted_plan`

### Exact schema references


### Exact command IDs

- `BOOT0_VERIFY_SIDECAR`
- `BOOT0_EXTRACT_PLAN`
- `BOOT0_VERIFY_EXTRACTED`

### Tests first

- `bootstrap/test_bootstrap_tools.py::test_bootstrap_scripts_parse`

### Positive vectors

- `BOOT0-VALID-ZIP-MANIFEST`

### Negative vectors

- `BOOT0-BAD-SIDECAR`
- `BOOT0-PATH-TRAVERSAL`
- `BOOT0-MANIFEST-MISMATCH`

### Implementation steps

- Run the failing exact test or precondition command and record the intended failure.
- Implement only the named files and symbols.
- Run every exact command ID and inspect the diff.
- Write the task evidence record, commit once, and stop.

### Acceptance criteria

- All exact commands pass
- All outputs are owned and content-addressed
- No authenticated discovery, provider call, or production authority is introduced

### Failure states

- `INPUT_INTEGRITY_FAILED`
- `DECLARED_ARTIFACT_MISSING`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-BOOT0-T01.json`

### Rollback

- Revert the single commit for V632-BOOT0-T01
- Restore the last accepted task-evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football-provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(boot0): verify and extract sealed plan input`

### Stop condition

Stop if any exact input, file, symbol, schema, vector, command, or authority condition is unresolved.

## V632-BOOT0-T02 — Create isolated authoring workspace

### Objective

Create the exact authoring root and copy the verified plan as immutable plan-input without source Git metadata, caches, or live evidence.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C2, V631-C3

### Dependencies

- `V632-BOOT0-T01`

### Exact files

- `/home/thenam176/betting-helper/hybrid-discovery-v6.3.2-authoring/.bootstrap/authoring-workspace-receipt.json`

### Exact symbols

- `bootstrap/create_authoring_workspace.py::create_authoring_workspace`

### Exact schema references


### Exact command IDs

- `BOOT0_CREATE_WORKSPACE`

### Tests first

- `bootstrap/test_bootstrap_tools.py::test_bootstrap_scripts_parse`

### Positive vectors

- `BOOT0-NEW-EMPTY-AUTHORING-ROOT`

### Negative vectors

- `BOOT0-ROOT-ALREADY-EXISTS`
- `BOOT0-GIT-COPIED`
- `BOOT0-LIVE-EVIDENCE-COPIED`

### Implementation steps

- Run the failing exact test or precondition command and record the intended failure.
- Implement only the named files and symbols.
- Run every exact command ID and inspect the diff.
- Write the task evidence record, commit once, and stop.

### Acceptance criteria

- All exact commands pass
- All outputs are owned and content-addressed
- No authenticated discovery, provider call, or production authority is introduced

### Failure states

- `INPUT_INTEGRITY_FAILED`
- `DECLARED_ARTIFACT_MISSING`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-BOOT0-T02.json`

### Rollback

- Revert the single commit for V632-BOOT0-T02
- Restore the last accepted task-evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football-provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(boot0): create isolated authoring workspace`

### Stop condition

Stop if any exact input, file, symbol, schema, vector, command, or authority condition is unresolved.

## V632-BOOT0-T03 — Initialize authoring Git repository

### Objective

Initialize a normal-history, no-remote Git repository for task-by-task authoring and record its actual initial commit/tree identity.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C2

### Dependencies

- `V632-BOOT0-T02`

### Exact files

- `/home/thenam176/betting-helper/hybrid-discovery-v6.3.2-authoring/.bootstrap/authoring-repository-receipt.json`

### Exact symbols

- `bootstrap/initialize_authoring_repository.py::initialize`

### Exact schema references


### Exact command IDs

- `BOOT0_INIT_AUTHORING_REPO`

### Tests first

- `bootstrap/test_bootstrap_tools.py::test_bootstrap_scripts_parse`

### Positive vectors

- `BOOT0-ZERO-REMOTE-CLEAN-INITIAL-COMMIT`

### Negative vectors

- `BOOT0-REMOTE-PRESENT`
- `BOOT0-DIRTY-INITIAL-STATE`
- `BOOT0-GIT-ALREADY-EXISTS`

### Implementation steps

- Run the failing exact test or precondition command and record the intended failure.
- Implement only the named files and symbols.
- Run every exact command ID and inspect the diff.
- Write the task evidence record, commit once, and stop.

### Acceptance criteria

- All exact commands pass
- All outputs are owned and content-addressed
- No authenticated discovery, provider call, or production authority is introduced

### Failure states

- `INPUT_INTEGRITY_FAILED`
- `DECLARED_ARTIFACT_MISSING`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-BOOT0-T03.json`

### Rollback

- Revert the single commit for V632-BOOT0-T03
- Restore the last accepted task-evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football-provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(boot0): initialize authoring git repository`

### Stop condition

Stop if any exact input, file, symbol, schema, vector, command, or authority condition is unresolved.
