# Reviewer Independence and Trust Contract

## Host review authority

Review launch authorizations and execution receipts are issued by `HOST_REVIEW_AUTHORITY` using Ed25519. The signing private key is created or imported only by explicit human action at:

```text
/home/thenam176/.config/hybrid-discovery/review-authority/ed25519-private-key.pem
```

It must have mode `0600` and must never exist inside the authoring repository, delivered runtime, sealed pack, review workspace, result tree or logs. The corresponding public record is loaded from the exact path in `review-authority.v1.json` and copied into the delivered trust-root artifact only after key ID and role validation.

## Launch authorization

A launch record binds the review role, run ID, sealed ZIP and manifest hashes, REPO0 receipt/commit/tree/file root, exact prompt and command registry hashes, workspace, two read-only input mounts, excluded roots, output root, one-use serial, nonce, not-before, expiry and maximum duration. Its audience is fixed to the independent-review launcher and production authority is `NONE`.

The authorization is atomically consumed before workspace creation. Crash after consumption burns the serial. Revocation or expiry cannot be overridden.

## Workspace/process isolation

Review A and Review B require different role, run ID, one-use serial, workspace root and output root. Both receive identical read-only content roots. The authoring tree and peer review output are not mounted. A finalizer rejects any unexpected changed path or command outside the exact registry.

## Fresh-session control

A human must start a fresh Codex session for each review and sign the procedural `HUMAN_FRESH_CODEX_SESSION` attestation. This proves only that the required procedure was attested; it is not represented as cryptographic proof of model-context independence.

## Freshness

Launch lifetime is exactly four hours. Aggregation must complete within one hour of the second review finalization. A host reboot, trust-root rotation, authorization revocation, workspace mismatch or expired receipt invalidates the review.

## Aggregation

The aggregator verifies both launch/receipt chains, distinct roles/serials/workspaces/results, identical sealed inputs, command roots, time windows and production authority `NONE`. Review B incomplete or any required cybersecurity command skipped yields HOLD.
