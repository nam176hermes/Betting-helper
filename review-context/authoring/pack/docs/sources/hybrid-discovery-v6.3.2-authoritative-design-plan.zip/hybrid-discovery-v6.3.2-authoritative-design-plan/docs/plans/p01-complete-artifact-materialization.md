# P01 — Complete artifact materialization

**Tasks:** 6

## Phase gate

`MATERIALIZATION_COMPLETE`

## V632-P01-T01 — Materialize runtime toolchains and test configuration

### Objective

Create exact runtime package manifests, lock policy, pytest discovery, TypeScript build/test/harness configs, and generated boundaries.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C2, V631-C5

### Dependencies

- `V632-MIG0-T06`

### Exact files

- `runtime/package.json`
- `runtime/pnpm-workspace.yaml`
- `runtime/pyproject.toml`
- `runtime/extension/package.json`
- `runtime/extension/tsconfig.json`
- `runtime/extension/tsconfig.test.json`
- `runtime/extension/tsconfig.harness.json`
- `runtime/extension/tsconfig.build.json`
- `runtime/tests/materialization/test_runtime_layout.py`

### Exact symbols

- `runtime/tests/materialization/test_runtime_layout.py::test_all_test_and_harness_directories_are_discovered`

### Exact schema references


### Exact command IDs

- `TEST_V632_P01_T01`

### Tests first

- `runtime/tests/materialization/test_runtime_layout.py`

### Positive vectors

- `V632-P01-T01-POS-01`

### Negative vectors

- `V632-P01-T01-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- pytest testpaths include all tests
- tsconfig.harness includes test-harness and durability/security tests
- No release test relies only on bare pytest discovery

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P01-T01.json`

### Rollback

- Revert only commit for V632-P01-T01
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p01): materialize runtime toolchains and test configuration`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P01-T02 — Materialize every declared source and test stub

### Objective

Create every planned runtime source, test, authoring tool, review tool, config, and harness entrypoint before exact reference validation.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C2, V631-C4

### Dependencies

- `V632-P01-T01`

### Exact files

- `runtime/tools/materialize_declared_stubs.py`
- `runtime/tests/materialization/test_declared_stubs.py`
- `runtime/src/moj_discovery/task_contracts.py`
- `runtime/extension/src/task-contracts.ts`
- `runtime/.contract-stub-registry.json`

### Exact symbols

- `runtime/tools/materialize_declared_stubs.py::materialize_declared_stubs`
- `runtime/tests/materialization/test_declared_stubs.py::test_every_declared_path_exists_or_is_classified_external`

### Exact schema references


### Exact command IDs

- `TEST_V632_P01_T02`

### Tests first

- `runtime/tests/materialization/test_declared_stubs.py`

### Positive vectors

- `V632-P01-T02-POS-01`

### Negative vectors

- `V632-P01-T02-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- Every planned internal path exists
- Every unimplemented symbol fails only with exact E_CONTRACT_NOT_IMPLEMENTED task code
- No missing import or config error

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P01-T02.json`

### Rollback

- Revert only commit for V632-P01-T02
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p01): materialize every declared source and test stub`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P01-T03 — Materialize schemas, registries, vectors, and exact schema definitions

### Objective

Create all planned normative schema files and resolvable JSON Pointer definitions before consumers are validated.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C4, V631-C5

### Dependencies

- `V632-P01-T02`

### Exact files

- `runtime/tests/materialization/test_normative_artifacts.py`
- `pack/docs/registries/crash-harness-registry.v1.json`
- `pack/docs/registries/clock-failure-precedence.v1.json`
- `pack/docs/registries/proof-coverage-matrix.v1.json`
- `pack/docs/registries/cybersecurity-command-registry.v1.json`
- `pack/docs/registries/review-command-registry.v1.json`
- `pack/docs/registries/seal-exclusions.v1.json`
- `pack/docs/schemas/command-registry.schema.json`
- `pack/docs/schemas/proof-coverage.schema.json`
- `pack/docs/schemas/review-launch-authorization.schema.json`
- `pack/docs/schemas/review-execution-receipt.schema.json`
- `pack/docs/schemas/review-result.schema.json`
- `pack/docs/schemas/self-review-record.schema.json`
- `pack/docs/schemas/external-seal-attestation.schema.json`
- `pack/docs/schemas/migration-receipt.schema.json`
- `pack/docs/configs/review-authority.v1.json`
- `pack/docs/security/review-trust-root.v1.json`

### Exact symbols

- `runtime/tests/materialization/test_normative_artifacts.py::test_all_schema_pointers_registries_and_vectors_resolve`

### Exact schema references


### Exact command IDs

- `TEST_V632_P01_T03`

### Tests first

- `runtime/tests/materialization/test_normative_artifacts.py`

### Positive vectors

- `V632-P01-T03-POS-01`

### Negative vectors

- `V632-P01-T03-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- Every schema reference resolves to an existing $defs member
- Every registry conforms to its schema
- No generic unresolved anchor

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P01-T03.json`

### Rollback

- Revert only commit for V632-P01-T03
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p01): materialize schemas, registries, vectors, and exact schema definitions`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P01-T04 — Materialize all crash and clock harness entrypoints

### Objective

Create compilable test-only child entrypoints and runner stubs for every crash family and both clock evaluators.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C2, V631-C5

### Dependencies

- `V632-P01-T03`

### Exact files

- `runtime/tests/materialization/test_harness_entrypoints.py`
- `runtime/extension/test-harness/indexeddb-crash-child.ts`
- `runtime/tools/loopback_ack_crash_child.py`
- `runtime/tools/sqlite_crash_child.py`
- `runtime/tools/gap_coherence_crash_child.py`
- `runtime/tools/destruction_crash_child.py`
- `runtime/src/moj_discovery/clock_vectors.py`
- `runtime/extension/src/contracts/clock-vectors.ts`

### Exact symbols

- `runtime/tests/materialization/test_harness_entrypoints.py::test_all_registered_harness_entrypoints_compile_and_emit_contract_not_implemented`

### Exact schema references


### Exact command IDs

- `TEST_V632_P01_T04`

### Tests first

- `runtime/tests/materialization/test_harness_entrypoints.py`

### Positive vectors

- `V632-P01-T04-POS-01`

### Negative vectors

- `V632-P01-T04-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All child entrypoints exist and compile
- No harness vector is left without an entrypoint
- Test-only privileged code is isolated from production build

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P01-T04.json`

### Rollback

- Revert only commit for V632-P01-T04
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p01): materialize all crash and clock harness entrypoints`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P01-T05 — Materialize review, cybersecurity, aggregation, export, and sealing tools

### Objective

Create all review and release tooling before candidate qualification or zero-parent export.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C2, V631-C6

### Dependencies

- `V632-P01-T04`

### Exact files

- `runtime/tests/materialization/test_review_release_tools.py`
- `runtime/tools/prepare_review_workspace.py`
- `runtime/tools/run_review_a_checks.py`
- `runtime/tools/run_review_b_checks.py`
- `runtime/tools/finalize_review.py`
- `runtime/tools/aggregate_reviews.py`
- `runtime/tools/build_self_review.py`
- `runtime/tools/verify_executable_references.py`
- `runtime/tools/verify_proof_coverage.py`
- `runtime/tools/export_zero_parent_candidate.py`
- `runtime/tools/seal_review_pack.py`

### Exact symbols

- `runtime/tests/materialization/test_review_release_tools.py::test_all_review_release_tools_exist_before_candidate_qualification`

### Exact schema references


### Exact command IDs

- `TEST_V632_P01_T05`

### Tests first

- `runtime/tests/materialization/test_review_release_tools.py`

### Positive vectors

- `V632-P01-T05-POS-01`

### Negative vectors

- `V632-P01-T05-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All release/review tools exist before P06
- Review configs reference executable tools, not prompt files
- Aggregator exists before reviews

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P01-T05.json`

### Rollback

- Revert only commit for V632-P01-T05
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p01): materialize review, cybersecurity, aggregation, export, and sealing tools`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P01-T06 — Issue MATERIALIZATION_COMPLETE gate

### Objective

Prove all declared internal artifacts are present, compilable, schema-resolvable, and owned while allowing intentional contract stubs.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C2, V631-C4

### Dependencies

- `V632-P01-T05`

### Exact files

- `runtime/src/moj_discovery/materialization_gate.py`
- `runtime/tests/materialization/test_materialization_gate.py`

### Exact symbols

- `runtime/src/moj_discovery/materialization_gate.py::validate_materialization_complete`
- `runtime/tests/materialization/test_materialization_gate.py::test_materialization_gate_rejects_missing_or_unowned_artifact`

### Exact schema references


### Exact command IDs

- `TEST_V632_P01_T06`

### Tests first

- `runtime/tests/materialization/test_materialization_gate.py`

### Positive vectors

- `V632-P01-T06-POS-01`

### Negative vectors

- `V632-P01-T06-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All internal artifacts are materialized
- External review/seal outputs are classified and not required yet
- Gate receipt records exact artifact root

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P01-T06.json`

### Rollback

- Revert only commit for V632-P01-T06
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p01): issue materialization_complete gate`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.
