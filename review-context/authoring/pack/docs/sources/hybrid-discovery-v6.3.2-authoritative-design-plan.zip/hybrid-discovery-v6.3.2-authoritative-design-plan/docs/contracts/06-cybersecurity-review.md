# Cybersecurity Review Contract

Review B is complete only when every command in `cybersecurity-command-registry.v1.json` executes in the authorized isolated workspace and produces a passing evidence record. The fixed areas are Chrome permission closure, CDP privilege reachability, dynamic dispatch, target escape, message smuggling, outbound network, authorization/trust, replay/revocation, credential/evidence denial, canonical hashing, no-archive policy, Bubblewrap isolation, supply-chain integrity and test-only privileged-code exclusion.

A command that is absent, skipped, unavailable, run from the wrong root, run after authorization expiry or not represented in the execution receipt makes `CYBERSECURITY_REVIEW_COMPLETE=NO`. The review result uses the `CybersecurityReviewResult` branch of the closed review schema. No prose checklist substitutes for command evidence.
