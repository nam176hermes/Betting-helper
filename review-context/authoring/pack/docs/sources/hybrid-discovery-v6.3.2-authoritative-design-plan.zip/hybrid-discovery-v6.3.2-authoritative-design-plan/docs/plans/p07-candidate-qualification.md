# P07 — Candidate qualification

**Tasks:** 3

## Phase gate

`CANDIDATE_QUALIFICATION_ACCEPTED`

## V632-P07-T01 — Run complete candidate command registry

### Objective

Execute every exact qualification command against the authoring runtime candidate with no authenticated operator/provider access.

### Authority

PLAN_AUTHORING

### Lifecycle

`QUALIFIED → QUALIFIED`

### Findings

V631-C5, V631-C6

### Dependencies

- `V632-P06-T03`

### Exact files

- `runtime/tools/run_command_registry.py`
- `runtime/tests/release/test_candidate_command_registry.py`

### Exact symbols

- `runtime/tools/run_command_registry.py::main`
- `runtime/tests/release/test_candidate_command_registry.py::test_candidate_mode_runs_every_required_command_once`

### Exact schema references


### Exact command IDs

- `VERIFY_V632_P07_T01`

### Tests first

- `runtime/tests/release/test_candidate_command_registry.py`

### Positive vectors

- `V632-P07-T01-POS-01`

### Negative vectors

- `V632-P07-T01-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P07-T01.json`

### Rollback

- Revert only commit for V632-P07-T01
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p07): run complete candidate command registry`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P07-T02 — Validate complete proof-coverage matrix

### Objective

Ensure every control promised by the plan has executed evidence and no prose-only coverage.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C5

### Dependencies

- `V632-P07-T01`

### Exact files

- `runtime/tests/release/test_full_proof_coverage.py`

### Exact symbols

- `runtime/tests/release/test_full_proof_coverage.py::test_every_proof_matrix_row_has_passing_evidence`

### Exact schema references

- `pack/docs/schemas/proof-coverage.schema.json#/$defs/ProofCoverageMatrix`

### Exact command IDs

- `VERIFY_V632_P07_T02`

### Tests first

- `runtime/tests/release/test_full_proof_coverage.py`

### Positive vectors

- `V632-P07-T02-POS-01`

### Negative vectors

- `V632-P07-T02-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P07-T02.json`

### Rollback

- Revert only commit for V632-P07-T02
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p07): validate complete proof-coverage matrix`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P07-T03 — Issue candidate qualification receipt

### Objective

Bind command-result root, proof matrix, exactness gates, clean candidate state, absence of live evidence, and production authority NONE.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C1, V631-C2, V631-C4, V631-C5, V631-C6

### Dependencies

- `V632-P07-T02`

### Exact files

- `runtime/tools/build_candidate_qualification_receipt.py`
- `runtime/tests/release/test_candidate_qualification_receipt.py`

### Exact symbols

- `runtime/tools/build_candidate_qualification_receipt.py::main`
- `runtime/tests/release/test_candidate_qualification_receipt.py::test_receipt_rejects_skipped_command_live_evidence_or_production_authority`

### Exact schema references


### Exact command IDs

- `VERIFY_V632_P07_T03`

### Tests first

- `runtime/tests/release/test_candidate_qualification_receipt.py`

### Positive vectors

- `V632-P07-T03-POS-01`

### Negative vectors

- `V632-P07-T03-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P07-T03.json`

### Rollback

- Revert only commit for V632-P07-T03
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p07): issue candidate qualification receipt`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.
