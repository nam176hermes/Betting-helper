# P06 — Executable-reference validation

**Tasks:** 3

## Phase gate

`EXECUTABLE_REFERENCE_COMPLETE`

## V632-P06-T01 — Resolve every executable file, symbol, schema, vector, command, and config

### Objective

Run exact resolution only after materialization and implementation phases have produced all artifacts.

### Authority

PLAN_AUTHORING

### Lifecycle

`MATERIALIZED → EXECUTABLE`

### Findings

V631-C2, V631-C4

### Dependencies

- `V632-P03-T07`
- `V632-P04-T04`
- `V632-P05-T08`

### Exact files

- `runtime/tools/verify_executable_references.py`
- `runtime/tests/release/test_executable_references.py`

### Exact symbols

- `runtime/tools/verify_executable_references.py::verify_executable_references`
- `runtime/tests/release/test_executable_references.py::test_every_executable_reference_resolves_without_placeholder`

### Exact schema references


### Exact command IDs

- `TEST_V632_P06_T01`

### Tests first

- `runtime/tests/release/test_executable_references.py`

### Positive vectors

- `V632-P06-T01-POS-01`

### Negative vectors

- `V632-P06-T01-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- Files unresolved zero
- Symbols unresolved zero
- Schema pointers unresolved zero
- Commands/configs unresolved zero

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P06-T01.json`

### Rollback

- Revert only commit for V632-P06-T01
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p06): resolve every executable file, symbol, schema, vector, command, and config`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P06-T02 — Verify test discovery, build configs, and command coverage

### Objective

Prove Python and TypeScript discovery includes bootstrap, migration, contracts, durability, clock, review, security, and release suites plus crash harness compilation.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C5

### Dependencies

- `V632-P06-T01`

### Exact files

- `runtime/tools/verify_test_discovery.py`
- `runtime/tests/release/test_verification_topology.py`

### Exact symbols

- `runtime/tools/verify_test_discovery.py::verify_verification_topology`
- `runtime/tests/release/test_verification_topology.py::test_all_proof_groups_are_discovered_and_registry_bound`

### Exact schema references


### Exact command IDs

- `TEST_V632_P06_T02`

### Tests first

- `runtime/tests/release/test_verification_topology.py`

### Positive vectors

- `V632-P06-T02-POS-01`

### Negative vectors

- `V632-P06-T02-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- Every proof group has exact commands
- Crash harness sources are compiled
- Bare pytest is not the only release proof

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P06-T02.json`

### Rollback

- Revert only commit for V632-P06-T02
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p06): verify test discovery, build configs, and command coverage`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P06-T03 — Issue EXECUTABLE_REFERENCE_COMPLETE gate

### Objective

Issue a content-addressed receipt only after all exact references and proof topology are executable.

### Authority

PLAN_AUTHORING

### Lifecycle

`EXECUTABLE → QUALIFIED`

### Findings

V631-C2, V631-C4, V631-C5

### Dependencies

- `V632-P06-T02`

### Exact files

- `runtime/src/moj_discovery/executable_gate.py`
- `runtime/tests/release/test_executable_complete_gate.py`

### Exact symbols

- `runtime/src/moj_discovery/executable_gate.py::issue_executable_reference_complete_receipt`
- `runtime/tests/release/test_executable_complete_gate.py::test_gate_rejects_intentional_stub_or_unexecuted_command`

### Exact schema references


### Exact command IDs

- `TEST_V632_P06_T03`

### Tests first

- `runtime/tests/release/test_executable_complete_gate.py`

### Positive vectors

- `V632-P06-T03-POS-01`

### Negative vectors

- `V632-P06-T03-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P06-T03.json`

### Rollback

- Revert only commit for V632-P06-T03
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p06): issue executable_reference_complete gate`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.
