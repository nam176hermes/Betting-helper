# P04 — Clock-vector qualification

**Tasks:** 4

## Phase gate

`CLOCK_QUALIFICATION_ACCEPTED`

## V632-P04-T01 — Freeze clock failure precedence registry

### Objective

Create one shared ordered registry for mapping rejection and acceptance so Python and TypeScript cannot diverge.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C5

### Dependencies

- `V632-P02-T03`

### Exact files

- `runtime/src/moj_discovery/clock_precedence.py`
- `runtime/tests/clock/test_failure_precedence_registry.py`
- `pack/docs/registries/clock-failure-precedence.v1.json`
- `pack/docs/vectors/inherited/clock-coherence-v6.2.json`
- `pack/docs/registries/clock-vector-coverage.v1.json`

### Exact symbols

- `runtime/src/moj_discovery/clock_precedence.py::load_clock_failure_precedence`
- `runtime/tests/clock/test_failure_precedence_registry.py::test_precedence_registry_is_total_unique_and_shared`

### Exact schema references


### Exact command IDs

- `TEST_V632_P04_T01`

### Tests first

- `runtime/tests/clock/test_failure_precedence_registry.py`

### Positive vectors

- `V632-P04-T01-POS-01`

### Negative vectors

- `V632-P04-T01-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced
- All 16 inherited mapping-negative vectors are mapped with exact expected error and eligibility
- All 65 named inherited clock/coherence vectors are accounted for by the coverage registry

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P04-T01.json`

### Rollback

- Revert only commit for V632-P04-T01
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p04): freeze clock failure precedence registry`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P04-T02 — Implement Python clock-vector evaluator

### Objective

Recompute interval, RTT, padding, uncertainty, drift, eligibility, and first failure from inputs without trusting expected fields.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C5

### Dependencies

- `V632-P04-T01`

### Exact files

- `runtime/src/moj_discovery/clock_vectors.py`
- `runtime/tests/clock/test_python_clock_vectors.py`

### Exact symbols

- `runtime/src/moj_discovery/clock_vectors.py::evaluate_clock_mapping_vector`
- `runtime/tests/clock/test_python_clock_vectors.py::test_python_evaluator_recomputes_all_positive_and_negative_vectors`

### Exact schema references


### Exact command IDs

- `TEST_V632_P04_T02`

### Tests first

- `runtime/tests/clock/test_python_clock_vectors.py`

### Positive vectors

- `V632-P04-T02-POS-01`

### Negative vectors

- `V632-P04-T02-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P04-T02.json`

### Rollback

- Revert only commit for V632-P04-T02
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p04): implement python clock-vector evaluator`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P04-T03 — Implement TypeScript clock-vector evaluator

### Objective

Implement the same evaluator from the same registry bytes and compile it under the test configuration.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C5

### Dependencies

- `V632-P04-T02`

### Exact files

- `runtime/extension/src/contracts/clock-vectors.ts`
- `runtime/extension/test/clock/clock-vectors.test.ts`

### Exact symbols

- `runtime/extension/src/contracts/clock-vectors.ts#evaluateClockMappingVector`
- `runtime/extension/test/clock/clock-vectors.test.ts#clockVectorQualificationSuite`

### Exact schema references


### Exact command IDs

- `COMPILE_V632_P04_T03`
- `TEST_TS_V632_P04_T03`

### Tests first

- `runtime/extension/test/clock/clock-vectors.test.ts`

### Positive vectors

- `V632-P04-T03-POS-01`

### Negative vectors

- `V632-P04-T03-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P04-T03.json`

### Rollback

- Revert only commit for V632-P04-T03
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p04): implement typescript clock-vector evaluator`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P04-T04 — Qualify cross-language clock parity and mutation sensitivity

### Objective

Run all vectors through both evaluators and prove expected eligibility/error/input mutations are detected.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C5

### Dependencies

- `V632-P04-T03`

### Exact files

- `runtime/tools/run_clock_vector_qualification.py`
- `runtime/tests/clock/test_clock_parity_and_mutation.py`

### Exact symbols

- `runtime/tools/run_clock_vector_qualification.py::run_clock_vector_qualification`
- `runtime/tests/clock/test_clock_parity_and_mutation.py::test_cross_language_drift_and_mutation_survivors_are_zero`

### Exact schema references


### Exact command IDs

- `TEST_V632_P04_T04`

### Tests first

- `runtime/tests/clock/test_clock_parity_and_mutation.py`

### Positive vectors

- `V632-P04-T04-POS-01`

### Negative vectors

- `V632-P04-T04-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- Cross-language drift zero
- Mutation survivors zero
- Skipped vectors zero

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P04-T04.json`

### Rollback

- Revert only commit for V632-P04-T04
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p04): qualify cross-language clock parity and mutation sensitivity`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.
