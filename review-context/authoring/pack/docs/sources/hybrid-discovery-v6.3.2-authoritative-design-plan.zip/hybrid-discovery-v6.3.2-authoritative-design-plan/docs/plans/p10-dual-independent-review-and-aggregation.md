# P10 — Dual independent review and aggregation

**Tasks:** 4

## Phase gate

`AGGREGATE_REVIEW_COMPLETE`

## V632-P10-T01 — Issue Review A launch authorization and isolated workspace

### Objective

Use external review authority to bind implementation-readiness role, exact sealed inputs, prompt/commands, one-use serial, expiry, isolated workspace, and allowed outputs.

### Authority

EXTERNAL_REVIEW

### Lifecycle

`SEALED → EXTERNAL_REVIEWED`

### Findings

V631-C6

### Dependencies

- `V632-P09-T04`

### Exact files

- `/home/thenam176/betting-helper/review-authorizations/hybrid-discovery-v6.3.2/review-a.authorization.json`
- `/home/thenam176/betting-helper/reviews/hybrid-discovery-v6.3.2/review-a/workspace-attestation.json`

### Exact symbols

- `runtime/tools/issue_review_launch_authorization.py::main`
- `runtime/tools/prepare_review_workspace.py::main`

### Exact schema references


### Exact command IDs

- `VERIFY_V632_P10_T01`

### Tests first

- `runtime/tests/review/test_review_launch_authorization.py`
- `runtime/tests/review/test_review_workspace_isolation.py`

### Positive vectors

- `V632-P10-T01-POS-01`

### Negative vectors

- `V632-P10-T01-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P10-T01.json`

### Rollback

- Revert only commit for V632-P10-T01
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p10): issue review a launch authorization and isolated workspace`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P10-T02 — Issue Review B launch authorization and isolated workspace

### Objective

Use a distinct role, serial, workspace, output root, prompt and command registry; exclude Review A output and authoring workspace.

### Authority

EXTERNAL_REVIEW

### Lifecycle

`SEALED → EXTERNAL_REVIEWED`

### Findings

V631-C6

### Dependencies

- `V632-P09-T04`

### Exact files

- `/home/thenam176/betting-helper/review-authorizations/hybrid-discovery-v6.3.2/review-b.authorization.json`
- `/home/thenam176/betting-helper/reviews/hybrid-discovery-v6.3.2/review-b/workspace-attestation.json`

### Exact symbols

- `runtime/tools/issue_review_launch_authorization.py::main`
- `runtime/tools/prepare_review_workspace.py::main`

### Exact schema references


### Exact command IDs

- `VERIFY_V632_P10_T02`

### Tests first

- `runtime/tests/review/test_review_launch_authorization.py`
- `runtime/tests/review/test_review_workspace_isolation.py`

### Positive vectors

- `V632-P10-T02-POS-01`

### Negative vectors

- `V632-P10-T02-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P10-T02.json`

### Rollback

- Revert only commit for V632-P10-T02
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p10): issue review b launch authorization and isolated workspace`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P10-T03 — Finalize independent review execution receipts

### Objective

Verify each review used its authorized workspace, exact inputs and commands, changed only allowed outputs, completed before expiry, and includes human fresh-session attestation.

### Authority

EXTERNAL_REVIEW

### Lifecycle

`SEALED → EXTERNAL_REVIEWED`

### Findings

V631-C6

### Dependencies

- `V632-P10-T01`
- `V632-P10-T02`

### Exact files

- `/home/thenam176/betting-helper/reviews/hybrid-discovery-v6.3.2/review-a/result.json`
- `/home/thenam176/betting-helper/reviews/hybrid-discovery-v6.3.2/review-a/execution-receipt.json`
- `/home/thenam176/betting-helper/reviews/hybrid-discovery-v6.3.2/review-b/result.json`
- `/home/thenam176/betting-helper/reviews/hybrid-discovery-v6.3.2/review-b/execution-receipt.json`

### Exact symbols

- `runtime/tools/finalize_review.py::main`
- `runtime/src/moj_discovery/review_authorization.py::verify_review_execution_receipt`

### Exact schema references

- `pack/docs/schemas/review-execution-receipt.schema.json#/$defs/ReviewExecutionReceipt`
- `pack/docs/schemas/review-result.schema.json#/$defs/ReviewResult`

### Exact command IDs

- `FINALIZE_A_V632_P10_T03`
- `FINALIZE_B_V632_P10_T03`

### Tests first

- `runtime/tests/review/test_review_workspace_isolation.py`

### Positive vectors

- `V632-P10-T03-POS-01`

### Negative vectors

- `V632-P10-T03-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- Review roles, serials, workspaces, outputs, and runs are distinct
- Both inputs bind identical sealed pack and baseline
- Human fresh-session attestation is present and explicitly procedural

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P10-T03.json`

### Rollback

- Revert only commit for V632-P10-T03
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p10): finalize independent review execution receipts`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P10-T04 — Aggregate independent reviews and issue handoff verdict

### Objective

Deterministically require Review A PASS, Review B PASS, valid independent receipts, no blocking finding, and production authority NONE before implementation readiness may be YES.

### Authority

EXTERNAL_REVIEW

### Lifecycle

`EXTERNAL_REVIEWED → EXTERNAL_REVIEWED`

### Findings

V631-C6

### Dependencies

- `V632-P10-T03`

### Exact files

- `/home/thenam176/betting-helper/reviews/hybrid-discovery-v6.3.2/aggregate/result.json`

### Exact symbols

- `runtime/tools/aggregate_reviews.py::main`
- `runtime/src/moj_discovery/review_aggregation.py::aggregate_independent_reviews`

### Exact schema references

- `pack/docs/schemas/review-result.schema.json#/$defs/ReviewResult`

### Exact command IDs

- `VERIFY_V632_P10_T04`

### Tests first

- `runtime/tests/review/test_review_aggregation_and_self_review.py`

### Positive vectors

- `V632-P10-T04-POS-01`

### Negative vectors

- `V632-P10-T04-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- Incomplete cybersecurity review yields HOLD
- READY YES with SAFE_TO_FREEZE_SCOPE0 NO is representable
- AUTHORIZED_PRODUCTION_PHASES remains NONE

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P10-T04.json`

### Rollback

- Revert only commit for V632-P10-T04
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p10): aggregate independent reviews and issue handoff verdict`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.
