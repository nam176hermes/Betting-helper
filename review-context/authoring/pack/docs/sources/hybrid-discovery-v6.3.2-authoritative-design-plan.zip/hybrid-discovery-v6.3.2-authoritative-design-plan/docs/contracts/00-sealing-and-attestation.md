# Sealing and External Attestation Contract

## Governed root

For every governed file, compute the byte SHA-256. Sort NFC UTF-8 relative paths by byte order. Each leaf is:

```text
SHA256(
  "HYBRID-DISCOVERY/v6.3.2/GOVERNED-FILE/v1" || 0x00 ||
  path_utf8 || 0x00 || raw_file_sha256_bytes
)
```

The root is:

```text
SHA256(
  "HYBRID-DISCOVERY/v6.3.2/GOVERNED-ROOT/v1" || 0x00 ||
  concat(uint32_be(path_length), path_utf8, leaf_hash_bytes)
)
```

The exclusion registry is closed. It excludes only the governed-root record, internal self-review, self-excluding manifest, archive, sidecar, and external seal attestation.

## Internal self-review

Binds governed root, task manifest, candidate qualification, REPO0 receipt and command-result root. It does not contain manifest, ZIP, sidecar or external-attestation hash.

## External attestation

Created after the deterministic ZIP. It binds archive hash, manifest hash, governed root, both self-review hashes, REPO0 receipt hash, baseline commit/tree/root, and seal timestamp. It remains outside the ZIP.
