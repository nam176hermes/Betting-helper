# P03 — Process-level durability qualification

**Tasks:** 7

## Phase gate

`DURABILITY_RELEASE_ACCEPTED`

## V632-P03-T01 — Freeze and validate complete crash-vector mapping

### Objective

Map every inherited and successor crash vector to exactly one harness, child command, checkpoint, state inspector, expected state, mutations, owner, and verification command.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C5

### Dependencies

- `V632-P02-T03`

### Exact files

- `runtime/src/moj_discovery/durability_registry.py`
- `runtime/tests/durability/test_crash_registry.py`
- `pack/docs/registries/crash-harness-registry.v1.json`
- `pack/docs/vectors/inherited/durability-crash-v6.2.json`
- `pack/docs/registries/crash-child-command-registry.v1.json`

### Exact symbols

- `runtime/src/moj_discovery/durability_registry.py::validate_crash_harness_registry`
- `runtime/tests/durability/test_crash_registry.py::test_every_normative_vector_has_one_process_execution_mapping`

### Exact schema references


### Exact command IDs

- `TEST_V632_P03_T01`

### Tests first

- `runtime/tests/durability/test_crash_registry.py`

### Positive vectors

- `V632-P03-T01-POS-01`

### Negative vectors

- `V632-P03-T01-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- Original vectors accounted 100%
- Process execution mapping 100%
- No declaration-only or unowned vector
- All 46 inherited case IDs are mapped exactly once
- Source case order, boundary, kill action, and expected state are preserved

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P03-T01.json`

### Rollback

- Revert only commit for V632-P03-T01
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p03): freeze and validate complete crash-vector mapping`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P03-T02 — Qualify real Chrome and IndexedDB test environment

### Objective

Prove a real Chrome/Chromium process can load the synthetic extension, persist IndexedDB, be abruptly killed, restart with the same profile, and expose the durable sentinel.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C5

### Dependencies

- `V632-P03-T01`

### Exact files

- `runtime/tools/qualify_chrome_indexeddb.py`
- `runtime/tests/durability/test_chrome_indexeddb_environment.py`
- `runtime/extension/test-harness/indexeddb-crash-child.ts`

### Exact symbols

- `runtime/tools/qualify_chrome_indexeddb.py::qualify_chrome_indexeddb_environment`
- `runtime/tests/durability/test_chrome_indexeddb_environment.py::test_real_chrome_indexeddb_survives_abrupt_process_kill`

### Exact schema references


### Exact command IDs

- `TEST_V632_P03_T02`

### Tests first

- `runtime/tests/durability/test_chrome_indexeddb_environment.py`

### Positive vectors

- `V632-P03-T02-POS-01`

### Negative vectors

- `V632-P03-T02-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- Real browser process used
- No in-memory or fake IndexedDB substitution
- Environment limitation yields BLOCKED

### Failure states

- `CHROME_BINARY_UNAVAILABLE`
- `EXTENSION_LOAD_FAILED`
- `INDEXEDDB_UNAVAILABLE`
- `ABRUPT_KILL_NOT_OBSERVED`
- `PROFILE_RESTART_FAILED`

### Evidence artifacts

- `.task-evidence/V632-P03-T02.json`

### Rollback

- Revert only commit for V632-P03-T02
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p03): qualify real chrome and indexeddb test environment`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P03-T03 — Execute IndexedDB spool crash matrix

### Objective

Process-execute every CHROME_INDEXEDDB vector around sequence allocation, payload commit, send boundary, and restart.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C5

### Dependencies

- `V632-P03-T02`

### Exact files

- `runtime/tools/run_indexeddb_crash_matrix.py`
- `runtime/tests/durability/test_indexeddb_process_crash.py`

### Exact symbols

- `runtime/tools/run_indexeddb_crash_matrix.py::run_indexeddb_crash_matrix`
- `runtime/tests/durability/test_indexeddb_process_crash.py::test_all_indexeddb_vectors_match_expected_restart_state`

### Exact schema references


### Exact command IDs

- `TEST_V632_P03_T03`
- `CRASH_VECTOR_IDB_01_BEFORE_TRANSACTION`
- `CRASH_VECTOR_IDB_02_DURING_SEQUENCE_ALLOCATION`
- `CRASH_VECTOR_IDB_03_DURING_ROW_PUT`
- `CRASH_VECTOR_IDB_04_AFTER_COMMIT`

### Tests first

- `runtime/tests/durability/test_indexeddb_process_crash.py`

### Positive vectors

- `V632-P03-T03-POS-01`

### Negative vectors

- `V632-P03-T03-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P03-T03.json`

### Rollback

- Revert only commit for V632-P03-T03
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p03): execute indexeddb spool crash matrix`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P03-T04 — Execute loopback delivery and ACK crash matrix

### Objective

Process-execute spool/send/backend-commit/ACK persistence and restart-handshake vectors.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C5

### Dependencies

- `V632-P03-T03`

### Exact files

- `runtime/tools/run_loopback_ack_crash_matrix.py`
- `runtime/tools/loopback_ack_crash_child.py`
- `runtime/tests/durability/test_loopback_ack_process_crash.py`

### Exact symbols

- `runtime/tools/run_loopback_ack_crash_matrix.py::run_loopback_ack_crash_matrix`
- `runtime/tests/durability/test_loopback_ack_process_crash.py::test_ack_never_crosses_uncommitted_or_gapped_position`

### Exact schema references


### Exact command IDs

- `TEST_V632_P03_T04`
- `CRASH_VECTOR_SEND_01_AFTER_SEND_BEFORE_BACKEND_BEGIN`
- `CRASH_VECTOR_ACK_01_BEFORE_EXTENSION_ACK_TRANSACTION`
- `CRASH_VECTOR_ACK_02_DURING_EXTENSION_ACK_TRANSACTION`
- `CRASH_VECTOR_ACK_03_AFTER_EXTENSION_ACK_TRANSACTION`
- `CRASH_VECTOR_ACK_04_BEFORE_BACKEND_CONFIRMATION_COMMIT`
- `CRASH_VECTOR_ACK_05_AFTER_BACKEND_CONFIRMATION_COMMIT`
- `CRASH_VECTOR_ACK_06_DUPLICATE_IDENTICAL`

### Tests first

- `runtime/tests/durability/test_loopback_ack_process_crash.py`

### Positive vectors

- `V632-P03-T04-POS-01`

### Negative vectors

- `V632-P03-T04-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P03-T04.json`

### Rollback

- Revert only commit for V632-P03-T04
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p03): execute loopback delivery and ack crash matrix`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P03-T05 — Execute SQLite transaction crash matrix

### Objective

SIGKILL child processes before, during, and after every RawCommit/Application/DerivedRevision/ReducerCursor/AckOutbox/COMMIT boundary.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C5

### Dependencies

- `V632-P03-T04`

### Exact files

- `runtime/tools/run_sqlite_crash_matrix.py`
- `runtime/tools/sqlite_crash_child.py`
- `runtime/tests/durability/test_sqlite_process_crash.py`

### Exact symbols

- `runtime/tools/run_sqlite_crash_matrix.py::run_sqlite_crash_matrix`
- `runtime/tests/durability/test_sqlite_process_crash.py::test_sql_transaction_is_all_or_none_after_sigkill`

### Exact schema references


### Exact command IDs

- `TEST_V632_P03_T05`
- `CRASH_VECTOR_SQL_01_AFTER_RAW_COMMIT_STATEMENT`
- `CRASH_VECTOR_SQL_02_AFTER_APPLICATION_STATEMENT`
- `CRASH_VECTOR_SQL_03_AFTER_DERIVED_REVISION_STATEMENT`
- `CRASH_VECTOR_SQL_04_AFTER_REDUCER_CURSOR_STATEMENT`
- `CRASH_VECTOR_SQL_05_AFTER_ACK_OUTBOX_STATEMENT`
- `CRASH_VECTOR_SQL_06_DURING_COMMIT`
- `CRASH_VECTOR_SQL_07_AFTER_COMMIT_BEFORE_ACK_SEND`

### Tests first

- `runtime/tests/durability/test_sqlite_process_crash.py`

### Positive vectors

- `V632-P03-T05-POS-01`

### Negative vectors

- `V632-P03-T05-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P03-T05.json`

### Rollback

- Revert only commit for V632-P03-T05
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p03): execute sqlite transaction crash matrix`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P03-T06 — Execute GAP, generation, and coherence crash matrix

### Objective

Process-execute conflict, predecessor close, GAP insert, generation transition, successor open, epoch close, and late-repair boundaries.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C5

### Dependencies

- `V632-P03-T05`

### Exact files

- `runtime/tools/run_gap_coherence_crash_matrix.py`
- `runtime/tools/gap_coherence_crash_child.py`
- `runtime/tests/durability/test_gap_generation_process_crash.py`

### Exact symbols

- `runtime/tools/run_gap_coherence_crash_matrix.py::run_gap_coherence_crash_matrix`
- `runtime/tests/durability/test_gap_generation_process_crash.py::test_closed_generation_and_epoch_never_reopen`

### Exact schema references


### Exact command IDs

- `TEST_V632_P03_T06`
- `CRASH_VECTOR_GAP_01_AFTER_GAP_INSERT`
- `CRASH_VECTOR_GAP_02_AFTER_SHOCK_INSERT`
- `CRASH_VECTOR_GAP_03_AFTER_COHERENCE_TRANSITION`
- `CRASH_VECTOR_GAP_04_AFTER_CONTROLLER_CLOSE`
- `CRASH_VECTOR_GAP_05_AFTER_EPOCH_BINDING`
- `CRASH_VECTOR_GAP_06_AFTER_PREDECESSOR_CLOSE`
- `CRASH_VECTOR_GAP_07_AFTER_GENERATION_TRANSITION`
- `CRASH_VECTOR_GAP_08_AFTER_SUCCESSOR_INSERT`
- `CRASH_VECTOR_GAP_09_DURING_COMMIT`
- `CRASH_VECTOR_GAP_10_AFTER_COMMIT`
- `CRASH_VECTOR_CONFLICT_01_SAME_POSITION_DIFFERENT_HASH`
- `CRASH_VECTOR_LATE_01_MISSING_POSITION_AFTER_GAP`
- `CRASH_VECTOR_GAP_11_REPEATED_GAP_IN_SUCCESSOR`
- `CRASH_VECTOR_CAPACITY_01_NORMAL_LIMIT_REACHED`
- `CRASH_VECTOR_CLOCK_01_AFTER_MAPPING_CLOSURE_INSERT`
- `CRASH_VECTOR_CLOCK_02_AFTER_CLOSURE_COMMIT_BEFORE_SHOCK`
- `CRASH_VECTOR_EPOCH_01_AFTER_SHOCK_BEFORE_CLOSE_COMMIT`
- `CRASH_VECTOR_EPOCH_02_AFTER_SHOCK_CLOSE_COMMIT`
- `CRASH_VECTOR_EPOCH_03_AFTER_PENDING_WRITES_BEFORE_COMMIT`
- `CRASH_VECTOR_EPOCH_04_DURING_NEW_EPOCH_OPEN_COMMIT`
- `CRASH_VECTOR_EPOCH_05_NEW_SHOCK_WHILE_PENDING`

### Tests first

- `runtime/tests/durability/test_gap_generation_process_crash.py`

### Positive vectors

- `V632-P03-T06-POS-01`

### Negative vectors

- `V632-P03-T06-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P03-T06.json`

### Rollback

- Revert only commit for V632-P03-T06
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p03): execute gap, generation, and coherence crash matrix`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P03-T07 — Execute destruction matrix and durability release gate

### Objective

Process-execute every whole-run destruction boundary, mutate every expected restart state, and issue the durability release receipt only when coverage is exact.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C5

### Dependencies

- `V632-P03-T06`

### Exact files

- `runtime/tools/run_destruction_crash_matrix.py`
- `runtime/tools/destruction_crash_child.py`
- `runtime/src/moj_discovery/durability_release.py`
- `runtime/tests/durability/test_destruction_and_release.py`

### Exact symbols

- `runtime/tools/run_destruction_crash_matrix.py::run_destruction_crash_matrix`
- `runtime/src/moj_discovery/durability_release.py::validate_full_durability_release`
- `runtime/tests/durability/test_destruction_and_release.py::test_declared_equals_executed_and_mutation_survivors_zero`

### Exact schema references


### Exact command IDs

- `TEST_V632_P03_T07`
- `CRASH_VECTOR_DESTROY_01_BEFORE_AUTHORITY`
- `CRASH_VECTOR_DESTROY_01A_AFTER_CONSUMPTION_BEFORE_INTENT`
- `CRASH_VECTOR_DESTROY_02_AFTER_INTENT_BEFORE_DELETION`
- `CRASH_VECTOR_DESTROY_03_AFTER_EXTENSION_DELETION`
- `CRASH_VECTOR_DESTROY_04_AFTER_BACKEND_DELETION`
- `CRASH_VECTOR_DESTROY_05_AFTER_BOTH_DELETIONS_BEFORE_PROOF`
- `CRASH_VECTOR_DESTROY_06_AFTER_PROOF`

### Tests first

- `runtime/tests/durability/test_destruction_and_release.py`

### Positive vectors

- `V632-P03-T07-POS-01`

### Negative vectors

- `V632-P03-T07-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- Declared process vectors equal executed vectors
- Declaration-only vectors zero
- Unexpected graceful exits zero
- Mutation survivors zero

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P03-T07.json`

### Rollback

- Revert only commit for V632-P03-T07
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p03): execute destruction matrix and durability release gate`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.
