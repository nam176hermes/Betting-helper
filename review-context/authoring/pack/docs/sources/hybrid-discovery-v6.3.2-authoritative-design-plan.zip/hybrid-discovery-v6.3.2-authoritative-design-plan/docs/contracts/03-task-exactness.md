# Task Exactness Contract

Every task has exact files, symbols, schema references, vectors and command IDs. Schema references use existing JSON Pointer `$defs`, never unresolved anchors. Prompts are inputs, not commands. Exact commands are argv arrays without shell interpolation, globs or placeholders. The declaration gate checks ownership; the executable gate checks actual resolution after materialization.
