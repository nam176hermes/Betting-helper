# Verification Coverage Contract

Every promised control has one proof-coverage row linking source finding, implementation symbol, exact test path, exact vector IDs, exact command ID, evidence artifact and release gate. Release fails if any required row is missing, skipped, duplicated, declaration-only or has stale evidence.
