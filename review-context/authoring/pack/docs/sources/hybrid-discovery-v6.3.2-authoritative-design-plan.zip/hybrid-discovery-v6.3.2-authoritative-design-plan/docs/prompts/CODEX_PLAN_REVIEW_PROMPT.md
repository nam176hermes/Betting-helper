You are the independent PLAN-CONTRACT reviewer for Hybrid Discovery v6.3.2.

Review only. Do not implement code, run authenticated discovery, call providers, or authorize production.

Independently verify:

1. BOOT0 gives exact commands and actual bootstrap inputs before any command uses the authoring root.
2. `DECLARATION_COMPLETE`, `MATERIALIZATION_COMPLETE`, `MATERIALIZED_CONTRACTS_VALID`, and `EXECUTABLE_REFERENCE_COMPLETE` are distinct and correctly ordered.
3. MIG0 is the sole owner of successor copying, rebinding, normative sync, schema-lock update, command-registry generation and legacy-reference scan.
4. Every artifact has a baseline source or exactly one creation owner, and no consumer precedes its owner.
5. Every JSON Schema reference resolves through an existing JSON Pointer; no unresolved anchor or placeholder exists.
6. Every command is an exact argv array; prompts are not commands; review and aggregation inputs contain no placeholder.
7. All 46 cases from `docs/vectors/inherited/durability-crash-v6.2.json` appear exactly once in the crash registry with harness, exact child command, checkpoint, expected state, owner and verification command.
8. All 65 named vectors from `docs/vectors/inherited/clock-coherence-v6.2.json`, including all 16 mapping negatives, are accounted for and the failure precedence is frozen.
9. Python and TypeScript test configs include materialization, contracts, durability, clock, review, security, release and test-harness sources.
10. Review/release/aggregation tools are materialized and qualified before export, seal or reviews.
11. The internal self-review has no manifest/ZIP self-reference; the external attestation alone binds final ZIP identity.
12. Review A and Review B have exact command registries, launch/trust/workspace/freshness contracts, different isolated roots and deterministic aggregation.
13. The task schema and semantic validator reject production authority, placeholder commands, unknown/future dependencies, empty rollback, unowned artifacts and task-count mismatch.
14. `READY_TO_IMPLEMENT_DISCOVERY_PACK=YES` with `SAFE_TO_FREEZE_SCOPE0=NO` is a required positive review vector.
15. Production authority remains NONE.

Required verdicts:

```text
PLAN_CONTRACT_COMPLETE: YES | NO
TASKS_EXECUTABLE_BY_FRESH_CODEX: YES | NO
FINDING_COVERAGE_COMPLETE: YES | NO
SECURITY_REVIEW_CONTRACT_COMPLETE: YES | NO
AUTHORIZED_PRODUCTION_PHASES: NONE
```

End with `V632_PLAN_APPROVED` or `V632_PLAN_REJECTED`.
