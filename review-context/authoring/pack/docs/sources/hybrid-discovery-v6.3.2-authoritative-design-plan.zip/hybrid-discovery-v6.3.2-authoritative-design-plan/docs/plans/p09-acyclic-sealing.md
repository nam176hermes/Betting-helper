# P09 — Acyclic sealing

**Tasks:** 4

## Phase gate

`PACK_SEALED`

## V632-P09-T01 — Assemble immutable review-pack candidate

### Objective

Assemble governed pack content, previous review imports, plans, registries, receipts, prompts, and source provenance after REPO0 receipt exists.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C1

### Dependencies

- `V632-P08-T03`

### Exact files

- `runtime/tools/assemble_review_pack.py`
- `runtime/tests/seal/test_pack_assembly.py`

### Exact symbols

- `runtime/tools/assemble_review_pack.py::assemble_review_pack`
- `runtime/tests/seal/test_pack_assembly.py::test_pack_inventory_has_no_external_review_or_final_seal_output`

### Exact schema references


### Exact command IDs

- `VERIFY_V632_P09_T01`

### Tests first

- `runtime/tests/seal/test_pack_assembly.py`

### Positive vectors

- `V632-P09-T01-POS-01`

### Negative vectors

- `V632-P09-T01-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P09-T01.json`

### Rollback

- Revert only commit for V632-P09-T01
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p09): assemble immutable review-pack candidate`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P09-T02 — Compute acyclic governed-content root

### Objective

Hash the normative governed file set while excluding root record, self-review, manifest, ZIP, sidecar, and external seal attestation according to a closed registry.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C1

### Dependencies

- `V632-P09-T01`

### Exact files

- `runtime/tools/compute_governed_content_root.py`
- `runtime/tests/seal/test_governed_content_root.py`
- `pack/docs/registries/seal-exclusions.v1.json`
- `pack/GOVERNED_CONTENT_ROOT.json`

### Exact symbols

- `runtime/tools/compute_governed_content_root.py::compute_governed_content_root`
- `runtime/tests/seal/test_governed_content_root.py::test_root_is_acyclic_and_exclusion_registry_is_closed`

### Exact schema references


### Exact command IDs

- `VERIFY_V632_P09_T02`

### Tests first

- `runtime/tests/seal/test_governed_content_root.py`

### Positive vectors

- `V632-P09-T02-POS-01`

### Negative vectors

- `V632-P09-T02-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P09-T02.json`

### Rollback

- Revert only commit for V632-P09-T02
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p09): compute acyclic governed-content root`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P09-T03 — Generate internal self-review without ZIP or manifest self-reference

### Objective

Create Markdown/JSON self-review binding only governed content, REPO0 receipt, candidate qualification, task manifest, and command result roots.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C1

### Dependencies

- `V632-P09-T02`

### Exact files

- `runtime/tools/build_self_review.py`
- `runtime/tests/seal/test_self_review_binding.py`
- `pack/SELF_REVIEW_REPORT.md`
- `pack/SELF_REVIEW_REPORT.json`

### Exact symbols

- `runtime/tools/build_self_review.py::main`
- `runtime/tests/seal/test_self_review_binding.py::test_self_review_does_not_bind_future_manifest_zip_or_sidecar`

### Exact schema references

- `pack/docs/schemas/self-review-record.schema.json#/$defs/SelfReviewRecord`

### Exact command IDs

- `VERIFY_V632_P09_T03`

### Tests first

- `runtime/tests/seal/test_self_review_binding.py`

### Positive vectors

- `V632-P09-T03-POS-01`

### Negative vectors

- `V632-P09-T03-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P09-T03.json`

### Rollback

- Revert only commit for V632-P09-T03
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p09): generate internal self-review without zip or manifest self-reference`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P09-T04 — Generate manifest, deterministic ZIP, sidecar, and external seal attestation

### Objective

Generate a self-excluding manifest, deterministic archive, sidecar, and external attestation binding ZIP/manifest/governed root/self-review/REPO0 without placing the final ZIP hash inside the ZIP.

### Authority

PLAN_AUTHORING

### Lifecycle

`QUALIFIED → SEALED`

### Findings

V631-C1

### Dependencies

- `V632-P09-T03`

### Exact files

- `runtime/tools/seal_review_pack.py`
- `runtime/tests/seal/test_deterministic_seal.py`
- `pack/MANIFEST_SHA256.json`
- `pack/docs/schemas/external-seal-attestation.schema.json`

### Exact symbols

- `runtime/tools/seal_review_pack.py::seal_review_pack`
- `runtime/tests/seal/test_deterministic_seal.py::test_independent_rebuild_is_byte_identical_and_external_attestation_matches`

### Exact schema references

- `pack/docs/schemas/external-seal-attestation.schema.json#/$defs/ExternalSealAttestation`

### Exact command IDs

- `VERIFY_V632_P09_T04`

### Tests first

- `runtime/tests/seal/test_deterministic_seal.py`

### Positive vectors

- `V632-P09-T04-POS-01`

### Negative vectors

- `V632-P09-T04-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P09-T04.json`

### Rollback

- Revert only commit for V632-P09-T04
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p09): generate manifest, deterministic zip, sidecar, and external seal attestation`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.
