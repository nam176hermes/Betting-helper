# Artifact Lifecycle Contract

Transitions are one-way:

```text
DECLARED → MATERIALIZED → EXECUTABLE → QUALIFIED → SEALED → EXTERNAL_REVIEWED
```

A declaration validator checks ownership and references without requiring future files. A materialization validator checks existence/compilation. Executable validation resolves symbols, pointers, vectors and commands. Qualification requires executed evidence. Sealing produces immutable delivery artifacts. External review outputs are never pack inputs.
