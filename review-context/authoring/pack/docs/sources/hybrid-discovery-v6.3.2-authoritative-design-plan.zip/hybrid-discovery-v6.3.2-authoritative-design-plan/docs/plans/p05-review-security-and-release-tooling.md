# P05 — Review security and release tooling

**Tasks:** 8

## Phase gate

`REVIEW_SECURITY_TOOLING_COMPLETE`

## V632-P05-T01 — Implement exact file and symbol resolver

### Objective

Resolve every declared Python function/class/method and TypeScript named export without cosmetic wrappers or placeholder prose.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C4

### Dependencies

- `V632-P01-T06`

### Exact files

- `runtime/tools/verify_task_symbols.py`
- `runtime/src/moj_discovery/symbol_inventory.py`
- `runtime/tests/exactness/test_task_symbols.py`
- `runtime/extension/test/exactness/task-symbols.test.ts`

### Exact symbols

- `runtime/tools/verify_task_symbols.py::main`
- `runtime/src/moj_discovery/symbol_inventory.py::resolve_python_symbol`
- `runtime/extension/test/exactness/task-symbols.test.ts#taskSymbolResolutionSuite`

### Exact schema references


### Exact command IDs

- `TEST_V632_P05_T01`

### Tests first

- `runtime/tests/exactness/test_task_symbols.py`
- `runtime/extension/test/exactness/task-symbols.test.ts`

### Positive vectors

- `V632-P05-T01-POS-01`

### Negative vectors

- `V632-P05-T01-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- Unresolved symbols zero
- Ambiguous symbols zero
- Unexported TypeScript symbols zero

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P05-T01.json`

### Rollback

- Revert only commit for V632-P05-T01
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p05): implement exact file and symbol resolver`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P05-T02 — Implement proof-coverage matrix verifier

### Objective

Map every promised control to finding, implementation symbol, exact test, vector IDs, command ID, evidence artifact, and release gate.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C5

### Dependencies

- `V632-P05-T01`

### Exact files

- `runtime/tools/verify_proof_coverage.py`
- `runtime/tests/coverage/test_proof_coverage_matrix.py`
- `pack/docs/registries/proof-coverage-matrix.v1.json`

### Exact symbols

- `runtime/tools/verify_proof_coverage.py::verify_proof_coverage_matrix`
- `runtime/tests/coverage/test_proof_coverage_matrix.py::test_every_promised_control_has_mechanical_proof`

### Exact schema references

- `pack/docs/schemas/proof-coverage.schema.json#/$defs/ProofCoverageMatrix`

### Exact command IDs

- `TEST_V632_P05_T02`

### Tests first

- `runtime/tests/coverage/test_proof_coverage_matrix.py`

### Positive vectors

- `V632-P05-T02-POS-01`

### Negative vectors

- `V632-P05-T02-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P05-T02.json`

### Rollback

- Revert only commit for V632-P05-T02
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p05): implement proof-coverage matrix verifier`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P05-T03 — Freeze cybersecurity command registry and attack matrix

### Objective

Create exact argv-based commands for every required Chrome, CDP, dispatch, target, message, outbound-network, trust, credential, hashing, custody, sandbox, supply-chain, and build-exclusion attack.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C6

### Dependencies

- `V632-P05-T02`

### Exact files

- `runtime/tools/verify_cybersecurity_registry.py`
- `runtime/tests/security/test_cybersecurity_command_registry.py`
- `pack/docs/registries/cybersecurity-command-registry.v1.json`
- `pack/docs/contracts/06-cybersecurity-review.md`

### Exact symbols

- `runtime/tools/verify_cybersecurity_registry.py::verify_cybersecurity_command_registry`
- `runtime/tests/security/test_cybersecurity_command_registry.py::test_every_security_area_has_exact_executable_commands`

### Exact schema references

- `pack/docs/schemas/command-registry.schema.json#/$defs/CommandRegistry`

### Exact command IDs

- `TEST_V632_P05_T03`

### Tests first

- `runtime/tests/security/test_cybersecurity_command_registry.py`

### Positive vectors

- `V632-P05-T03-POS-01`

### Negative vectors

- `V632-P05-T03-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P05-T03.json`

### Rollback

- Revert only commit for V632-P05-T03
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p05): freeze cybersecurity command registry and attack matrix`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P05-T04 — Implement host-issued review launch authorization

### Objective

Define and verify role-bound, pack-bound, baseline-bound, workspace-bound, one-use, expiring review authorizations issued outside the authoring session.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C6

### Dependencies

- `V632-P05-T03`

### Exact files

- `runtime/src/moj_discovery/review_authorization.py`
- `runtime/tools/issue_review_launch_authorization.py`
- `runtime/tests/review/test_review_launch_authorization.py`
- `pack/docs/schemas/review-launch-authorization.schema.json`
- `pack/docs/registries/reviewer-role-registry.v1.json`
- `runtime/tools/bootstrap_review_authority.py`
- `runtime/tests/review/test_review_authority_bootstrap.py`
- `runtime/review-config/review-authority.v1.json`
- `pack/docs/configs/review-authority.v1.json`
- `pack/docs/security/review-trust-root.v1.json`

### Exact symbols

- `runtime/src/moj_discovery/review_authorization.py::verify_review_launch_authorization`
- `runtime/tools/issue_review_launch_authorization.py::main`
- `runtime/tests/review/test_review_launch_authorization.py::test_wrong_role_workspace_pack_or_expiry_is_rejected`
- `runtime/tools/bootstrap_review_authority.py::bootstrap_review_authority`
- `runtime/tests/review/test_review_authority_bootstrap.py::test_private_key_stays_outside_all_governed_roots`

### Exact schema references

- `pack/docs/schemas/review-launch-authorization.schema.json#/$defs/ReviewLaunchAuthorization`

### Exact command IDs

- `TEST_V632_P05_T04`
- `VERIFY_REVIEW_AUTHORITY_BOOTSTRAP`

### Tests first

- `runtime/tests/review/test_review_launch_authorization.py`

### Positive vectors

- `V632-P05-T04-POS-01`

### Negative vectors

- `V632-P05-T04-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- Launch authority private key is external to pack/runtime/authoring tree
- Authorization binds role, prompt, commands, workspace, inputs, outputs, freshness, and one-use serial
- Model-context freshness is explicitly human-attested, not cryptographically claimed
- Host review trust source and private-key custody path are explicit
- Private signing key is mechanically absent from authoring, runtime, pack, workspace, result, and log roots
- Launch lifetime is four hours and aggregation freshness is one hour

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P05-T04.json`

### Rollback

- Revert only commit for V632-P05-T04
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p05): implement host-issued review launch authorization`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P05-T05 — Implement isolated review workspace preparation and finalization

### Objective

Prepare Bubblewrap/read-only review workspaces, exclude authoring and peer-review outputs, attest mount/process facts, and finalize only allowed outputs.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C6

### Dependencies

- `V632-P05-T04`

### Exact files

- `runtime/tools/prepare_review_workspace.py`
- `runtime/tools/finalize_review.py`
- `runtime/tests/review/test_review_workspace_isolation.py`

### Exact symbols

- `runtime/tools/prepare_review_workspace.py::main`
- `runtime/tools/finalize_review.py::main`
- `runtime/tests/review/test_review_workspace_isolation.py::test_authoring_tree_and_peer_review_output_are_not_mounted`

### Exact schema references


### Exact command IDs

- `TEST_V632_P05_T05`

### Tests first

- `runtime/tests/review/test_review_workspace_isolation.py`

### Positive vectors

- `V632-P05-T05-POS-01`

### Negative vectors

- `V632-P05-T05-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P05-T05.json`

### Rollback

- Revert only commit for V632-P05-T05
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p05): implement isolated review workspace preparation and finalization`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P05-T06 — Implement Review A mechanical runner

### Objective

Run exact implementation-readiness commands and emit a closed evidence bundle for an independent reviewer.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C6

### Dependencies

- `V632-P05-T05`

### Exact files

- `runtime/tools/run_review_a_checks.py`
- `runtime/tests/review/test_review_a_runner.py`
- `runtime/review-config/review-a.v1.json`
- `pack/docs/prompts/CODEX_IMPLEMENTATION_READINESS_REVIEW_PROMPT.md`

### Exact symbols

- `runtime/tools/run_review_a_checks.py::main`
- `runtime/tests/review/test_review_a_runner.py::test_review_a_runner_executes_only_registry_commands`

### Exact schema references


### Exact command IDs

- `TEST_V632_P05_T06`

### Tests first

- `runtime/tests/review/test_review_a_runner.py`

### Positive vectors

- `V632-P05-T06-POS-01`

### Negative vectors

- `V632-P05-T06-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P05-T06.json`

### Rollback

- Revert only commit for V632-P05-T06
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p05): implement review a mechanical runner`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P05-T07 — Implement Review B cybersecurity runner

### Objective

Run every exact cybersecurity command and emit a closed evidence bundle; missing command execution is HOLD.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C6

### Dependencies

- `V632-P05-T06`

### Exact files

- `runtime/tools/run_review_b_checks.py`
- `runtime/tests/review/test_review_b_runner.py`
- `runtime/review-config/review-b.v1.json`
- `pack/docs/prompts/CODEX_CYBERSECURITY_REVIEW_PROMPT.md`

### Exact symbols

- `runtime/tools/run_review_b_checks.py::main`
- `runtime/tests/review/test_review_b_runner.py::test_review_b_runner_rejects_missing_or_skipped_security_area`

### Exact schema references


### Exact command IDs

- `TEST_V632_P05_T07`

### Tests first

- `runtime/tests/review/test_review_b_runner.py`

### Positive vectors

- `V632-P05-T07-POS-01`

### Negative vectors

- `V632-P05-T07-NEG-01`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P05-T07.json`

### Rollback

- Revert only commit for V632-P05-T07
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p05): implement review b cybersecurity runner`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.

## V632-P05-T08 — Implement deterministic review aggregation and internal self-review tooling

### Objective

Validate review results/receipts, enforce independence/freshness, aggregate verdicts, and build a non-authoritative internal self-review that never binds the future ZIP.

### Authority

PLAN_AUTHORING

### Lifecycle

`DECLARED → MATERIALIZED`

### Findings

V631-C1, V631-C6

### Dependencies

- `V632-P05-T07`

### Exact files

- `runtime/tools/aggregate_reviews.py`
- `runtime/tools/build_self_review.py`
- `runtime/src/moj_discovery/review_aggregation.py`
- `runtime/tests/review/test_review_aggregation_and_self_review.py`
- `pack/docs/schemas/review-execution-receipt.schema.json`
- `pack/docs/schemas/review-result.schema.json`
- `pack/docs/schemas/self-review-record.schema.json`

### Exact symbols

- `runtime/tools/aggregate_reviews.py::main`
- `runtime/tools/build_self_review.py::main`
- `runtime/src/moj_discovery/review_aggregation.py::aggregate_independent_reviews`
- `runtime/tests/review/test_review_aggregation_and_self_review.py::test_ready_yes_scope_no_is_valid_and_incomplete_security_holds`

### Exact schema references

- `pack/docs/schemas/review-execution-receipt.schema.json#/$defs/ReviewExecutionReceipt`
- `pack/docs/schemas/review-result.schema.json#/$defs/ReviewResult`
- `pack/docs/schemas/self-review-record.schema.json#/$defs/SelfReviewRecord`

### Exact command IDs

- `TEST_V632_P05_T08`

### Tests first

- `runtime/tests/review/test_review_aggregation_and_self_review.py`

### Positive vectors

- `REVIEW-READY-YES-SCOPE0-NO`

### Negative vectors

- `REVIEW-READY-YES-REPO-NO`
- `REVIEW-READY-YES-E0-NO`
- `REVIEW-INCOMPLETE-CYBERSECURITY`
- `REVIEW-SAME-WORKSPACE`
- `REVIEW-SAME-LAUNCH-SERIAL`

### Implementation steps

- Create the failing exact test and confirm the declared failure reason.
- Implement only the named symbols and artifacts.
- Run the exact task commands and inspect the diff.
- Write the task evidence record and stop.

### Acceptance criteria

- All exact commands pass
- All declared outputs are content-addressed
- No production authority is introduced

### Failure states

- `MISSING_DECLARED_ARTIFACT`
- `REFERENCE_UNRESOLVED`
- `VERIFICATION_FAILED`
- `AUTHORITY_BOUNDARY_VIOLATION`

### Evidence artifacts

- `.task-evidence/V632-P05-T08.json`

### Rollback

- Revert only commit for V632-P05-T08
- Restore prior accepted task evidence root

### Out of scope

- Authenticated Mise-o-jeu discovery
- Football provider calls
- Production WDL, market, Paper, Real Money, Cashout, or Hermes

### Commit

`plan(p05): implement deterministic review aggregation and internal self-review tooling`

### Stop condition

Stop immediately if any exact input, path, symbol, schema, command, or authority assumption is unresolved.
