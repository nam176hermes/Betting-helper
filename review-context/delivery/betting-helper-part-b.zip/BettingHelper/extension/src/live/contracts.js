/** Closed live records. Compose with the pinned local standalone schema validator. */
import { canonicalBytes } from "../canonical.js";
const counters = new Set(["received_mono_us", "content_revision", "binding_revision",
    "capture_revision", "browser_mono_us", "revision", "before_revision", "epoch",
    "generation", "sequence", "counter", "first_sequence", "last_sequence", "monotonic_us"]);
function scalars(value, key = "") {
    if (typeof value === "string") {
        if (Array.from(value).some(c => c.charCodeAt(0) < 32 || c.charCodeAt(0) === 127) ||
            (counters.has(key) && BigInt(value) > 9223372036854775807n))
            throw new Error();
    }
    else if (Array.isArray(value)) {
        for (const child of value)
            scalars(child, key);
    }
    else if (value !== null && typeof value === "object") {
        for (const [name, child] of Object.entries(value))
            scalars(child, name);
    }
}
export function validateLiveRecord(value, kind, validateSchema) {
    try {
        if (!validateSchema(value, kind))
            throw new Error();
        const record = value;
        if (canonicalBytes(record).byteLength > 65536)
            throw new Error();
        scalars(record);
        if (kind === "LiveEvent")
            validateLiveRecord(record["payload"], record["payload_type"], validateSchema);
        if (kind === "MarketBook") {
            const selections = Object.values(value.selections);
            if (new Set(selections.map(s => s.selection_id)).size !== 3 ||
                selections.some(s => Number(s.decimal_odds) <= 1))
                throw new Error();
        }
        if ((kind === "ProviderState" || kind === "FixtureBinding") &&
            record["home_id"] === record["away_id"])
            throw new Error();
        if (kind === "ProviderState" && record["provider_updated_at"] !== null)
            throw new Error();
        return structuredClone(record);
    }
    catch {
        throw new Error("E_LIVE_RECORD");
    }
}
