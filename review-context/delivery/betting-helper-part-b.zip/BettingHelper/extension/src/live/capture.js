import { handleCaptureMessage } from "./background.js";
import { parseStrictJson } from "../canonical.js";
const rawFields = ["fixture_id", "home_team", "away_team", "home_id", "away_id", "market_root", "horizon_label",
    "home_selection", "draw_selection", "away_selection", "home_odds", "draw_odds", "away_odds", "market_status", "score", "period"];
/** Authenticated one-shot loopback exchange. No reconnect, URL input or provider key. */
export async function runDiscoveryTicket(ticketText, tabId, signal) {
    const ticket = parseStrictJson(new TextEncoder().encode(ticketText));
    if (!ticket || Object.keys(ticket).sort().join() !== "key,kind,runId" || ticket["kind"] !== "OPERATOR_DISCOVERY" ||
        typeof ticket["runId"] !== "string" || !uuid.test(ticket["runId"]) ||
        typeof ticket["key"] !== "string" || !/^[A-Za-z0-9_-]{43}$/.test(ticket["key"]) ||
        !Number.isSafeInteger(tabId) || tabId < 0)
        throw Error("E_DISCOVERY_TICKET");
    if (signal?.aborted)
        throw Error("E_DISCOVERY_CANCELLED");
    const bytes = Uint8Array.from(atob(ticket["key"].replaceAll("-", "+").replaceAll("_", "/") + "="), c => c.charCodeAt(0));
    if (bytes.length !== 32)
        throw Error("E_DISCOVERY_TICKET");
    const key = await crypto.subtle.importKey("raw", bytes, { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
    bytes.fill(0);
    if (signal?.aborted)
        throw Error("E_DISCOVERY_CANCELLED");
    const socket = new WebSocket("ws://127.0.0.1:8765/operator-discovery");
    const controller = new AbortController();
    const cancel = () => { controller.abort(); socket.close(); };
    signal?.addEventListener("abort", cancel, { once: true });
    if (signal?.aborted)
        cancel();
    const timeout = setTimeout(cancel, 600000);
    let nonce = "";
    const preimage = (kind, payload = "") => new TextEncoder().encode(`BH-DISCOVERY/v1\0${kind}\0${String(ticket["runId"])}\0${nonce}\0${payload}`);
    const mac = async (kind, payload = "") => Array.from(new Uint8Array(await crypto.subtle.sign("HMAC", key, preimage(kind, payload))), n => n.toString(16).padStart(2, "0")).join("");
    const requireOpen = () => {
        if (controller.signal.aborted)
            throw Error("E_DISCOVERY_CANCELLED");
        if (socket.readyState !== WebSocket.OPEN)
            throw Error("E_DISCOVERY_CONNECTION");
    };
    const receive = () => new Promise((resolve, reject) => {
        if (controller.signal.aborted) {
            reject(Error("E_DISCOVERY_CANCELLED"));
            return;
        }
        if (socket.readyState === WebSocket.CLOSING || socket.readyState === WebSocket.CLOSED) {
            reject(Error("E_DISCOVERY_CONNECTION"));
            return;
        }
        const abort = () => { reject(Error("E_DISCOVERY_CANCELLED")); };
        controller.signal.addEventListener("abort", abort, { once: true });
        const cleanup = () => { controller.signal.removeEventListener("abort", abort); };
        socket.onclose = socket.onerror = () => { cleanup(); controller.abort(); reject(Error("E_DISCOVERY_CONNECTION")); };
        socket.onmessage = (event) => {
            try {
                if (typeof event.data !== "string" || new TextEncoder().encode(event.data).length > 16384)
                    throw Error();
                const value = parseStrictJson(new TextEncoder().encode(event.data));
                if (!value || typeof value !== "object" || Array.isArray(value))
                    throw Error();
                cleanup();
                resolve(value);
            }
            catch {
                cleanup();
                reject(Error("E_DISCOVERY_MESSAGE"));
            }
        };
    });
    const verified = async (kind) => {
        const frame = await receive();
        if (Object.keys(frame).sort().join() !== "mac,payload" || typeof frame["payload"] !== "string" ||
            typeof frame["mac"] !== "string" || !/^[a-f0-9]{64}$/.test(frame["mac"]))
            throw Error("E_DISCOVERY_FRAME");
        const signature = Uint8Array.from(frame["mac"].match(/../g) ?? [], h => parseInt(h, 16));
        if (!await crypto.subtle.verify("HMAC", key, signature, preimage(kind, frame["payload"])))
            throw Error("E_DISCOVERY_MAC");
        return parseStrictJson(new TextEncoder().encode(frame["payload"]));
    };
    try {
        // Install the first receiver before open, so the greeting cannot race registration.
        const greeting = await receive();
        if (Object.keys(greeting).sort().join() !== "nonce,run_id" || greeting["run_id"] !== ticket["runId"] ||
            typeof greeting["nonce"] !== "string" || !/^[a-f0-9]{64}$/.test(greeting["nonce"]))
            throw Error("E_DISCOVERY_GREETING");
        nonce = greeting["nonce"];
        const planPromise = verified("PLAN");
        void planPromise.catch(() => undefined);
        const authMac = await mac("AUTH");
        requireOpen();
        socket.send(JSON.stringify({ mac: authMac }));
        const plan = await planPromise;
        requireOpen();
        if (Object.hasOwn(plan, "tabId"))
            throw Error("E_DISCOVERY_PLAN");
        const sample = await takeDiscoverySample({ ...plan, tabId }, controller.signal);
        requireOpen();
        const payload = JSON.stringify(sample);
        if (new TextEncoder().encode(payload).length > 12000)
            throw Error("E_DISCOVERY_MESSAGE");
        const ackPromise = verified("ACK");
        void ackPromise.catch(() => undefined);
        const sampleMac = await mac("SAMPLE", payload);
        requireOpen();
        socket.send(JSON.stringify({ payload, mac: sampleMac }));
        const ack = await ackPromise;
        if (Object.keys(ack).join() !== "status" || ack["status"] !== "UNADMITTED_SAMPLE_SAVED")
            throw Error("E_DISCOVERY_ACK");
    }
    finally {
        clearTimeout(timeout);
        signal?.removeEventListener("abort", cancel);
        cancel();
    }
}
/** One unadmitted sample. The caller must first obtain reviewed, user-confirmed scope.
 * This is deliberately separate from accepted-profile capture and never creates a book. */
export async function takeDiscoverySample(input, signal) {
    if (signal?.aborted)
        throw Error("E_DISCOVERY_CANCELLED");
    const plan = structuredClone(input), url = new URL(plan.exactUrl), start = performance.now(), wall = Date.now();
    const selectors = plan.selectors;
    const mapping = selectors && Object.keys(selectors).join() === "selection_mode" && selectors["selection_mode"] === "USER_SELECTED_REGION_V1";
    if (Object.keys(plan).sort().join() !== "exactUrl,expiresAt,fieldMapHash,leaseMs,selectors,sourceKind,tabId" ||
        !(plan.sourceKind === "SYNTHETIC_TEST" && url.protocol === "http:" && url.hostname === "127.0.0.1" ||
            plan.sourceKind === "OBSERVED_REAL" && url.origin === "https://miseojeuplus.espacejeux.com") ||
        url.username || url.password || url.search || url.hash || url.href !== plan.exactUrl ||
        !Number.isSafeInteger(plan.tabId) || plan.tabId < 0 || !/^[a-f0-9]{64}$/.test(plan.fieldMapHash) ||
        !Number.isFinite(Date.parse(plan.expiresAt)) || Date.parse(plan.expiresAt) <= wall ||
        !Number.isSafeInteger(plan.leaseMs) || plan.leaseMs < 1 || plan.leaseMs > 600000 ||
        !selectors || (!mapping && (Object.keys(selectors).sort().join() !== [...rawFields, "match_root"].sort().join() ||
        typeof selectors["match_root"] !== "string")))
        throw Error("E_DISCOVERY_SCOPE");
    for (const value of Object.values(plan.selectors)) {
        if (value !== null && (typeof value !== "string" || value.length < 1 || value.length > 512 ||
            /password|passwd|token|cookie|account|balance|betslip|cashout|login|email|username|wallet|form|input|textarea|iframe|contenteditable/i.test(value)))
            throw Error("E_DISCOVERY_SELECTOR");
    }
    const remaining = () => {
        if (signal?.aborted)
            throw Error("E_DISCOVERY_CANCELLED");
        const ms = Math.floor(Math.min(plan.leaseMs - (performance.now() - start), Date.parse(plan.expiresAt) - Date.now()));
        if (Date.now() < wall || ms <= 0)
            throw Error("E_DISCOVERY_EXPIRED");
        return ms;
    };
    const bounded = async (action) => {
        const ms = remaining();
        let timer;
        let abort;
        const stopped = new Promise((_, reject) => {
            abort = () => { reject(Error("E_DISCOVERY_CANCELLED")); };
            signal?.addEventListener("abort", abort, { once: true });
            timer = setTimeout(() => { reject(Error("E_DISCOVERY_EXPIRED")); }, ms);
        });
        try {
            const result = await Promise.race([action(), stopped]);
            remaining();
            return result;
        }
        finally {
            clearTimeout(timer);
            if (abort)
                signal?.removeEventListener("abort", abort);
        }
    };
    const tab = await bounded(() => chrome.tabs.get(plan.tabId));
    if (tab.url !== plan.exactUrl || !tab.active || tab.discarded)
        throw Error("E_DISCOVERY_TAB");
    const injection = await bounded(() => chrome.scripting.executeScript({ target: { tabId: plan.tabId, frameIds: [0] },
        files: ["src/live/dom_reader.js"], world: "ISOLATED" }));
    const documentId = injection[0]?.documentId;
    if (injection.length !== 1 || injection[0]?.frameId !== 0 || !documentId)
        throw Error("E_DISCOVERY_DOCUMENT");
    const captureId = crypto.randomUUID(), documentEpoch = crypto.randomUUID();
    let replaced = false;
    const isReplaced = () => replaced;
    const changed = (id, change) => {
        if (id === plan.tabId && (change.status === "loading" || change.discarded === true || change.url !== undefined))
            replaced = true;
    };
    const removed = (id) => { if (id === plan.tabId)
        replaced = true; };
    chrome.tabs.onUpdated.addListener(changed);
    chrome.tabs.onRemoved.addListener(removed);
    const send = (operation, value) => chrome.tabs.sendMessage(plan.tabId, { kind: "FIXED_DOM_READONLY", operation, value }, { documentId });
    try {
        const ready = await bounded(() => send("DISCOVERY_INIT", { captureId, profileHash: plan.fieldMapHash,
            bindingRevision: "0", documentEpoch, exactUrl: plan.exactUrl, leaseMs: remaining(), selectors: plan.selectors }));
        if (!ready || ready.status !== "READY")
            throw Error("E_DISCOVERY_INIT");
        const challenge = Array.from(crypto.getRandomValues(new Uint8Array(32)), n => n.toString(16).padStart(2, "0")).join("");
        const reply = await bounded(() => send("READ", challenge));
        if (!reply || Object.keys(reply).sort().join() !== "browserMonoUs,challenge,first,firstReadMonoUs,observedAtUtc,second,status" ||
            reply["status"] !== "DISCOVERY_SAMPLE" || reply["challenge"] !== challenge)
            throw Error("E_DISCOVERY_SAMPLE");
        const observed = [reply["first"], reply["second"]];
        for (const fields of observed) {
            if (mapping) {
                validateSelectionMap(fields);
                continue;
            }
            if (!fields || Object.keys(fields).sort().join() !== [...rawFields].sort().join())
                throw Error("E_DISCOVERY_FIELDS");
            for (const value of Object.values(fields))
                if (value !== null)
                    text(value);
        }
        const interval = counter(reply["browserMonoUs"]) - counter(reply["firstReadMonoUs"]);
        if ((mapping ? JSON.stringify(observed[0]) !== JSON.stringify(observed[1]) : rawFields.some(name => observed[0]?.[name] !== observed[1]?.[name])) || interval < 100000n || interval > 1000000n ||
            !Number.isFinite(Date.parse(text(reply["observedAtUtc"]))))
            throw Error("E_DISCOVERY_UNSTABLE");
        const current = await bounded(() => chrome.tabs.get(plan.tabId));
        remaining();
        if (isReplaced() || current.url !== plan.exactUrl || !current.active || current.discarded)
            throw Error("E_DISCOVERY_TAB_CHANGED");
        return { status: "UNADMITTED_SAMPLE", source_kind: plan.sourceKind, exact_url: plan.exactUrl,
            field_map_hash: plan.fieldMapHash, tab_id: plan.tabId, document_id: documentId, document_epoch: documentEpoch,
            fields: observed[1], observed_at_utc: reply["observedAtUtc"], browser_mono_us: reply["browserMonoUs"],
            profile_accepted: false, binding_verified: false };
    }
    finally {
        chrome.tabs.onUpdated.removeListener(changed);
        chrome.tabs.onRemoved.removeListener(removed);
        // A dead document cannot acknowledge STOP; its reader lease independently expires.
        void send("STOP", captureId).catch(() => undefined);
    }
}
function validateSelectionMap(value) {
    if (!value || typeof value !== "object")
        throw Error("E_DISCOVERY_MAP");
    const map = value;
    if (Object.keys(map).sort().join() !== "candidates,match_root_selector" ||
        typeof map["match_root_selector"] !== "string" || map["match_root_selector"].length > 512 ||
        !Array.isArray(map["candidates"]) || !map["candidates"].length || map["candidates"].length > 32 ||
        new TextEncoder().encode(JSON.stringify(map)).length > 10000)
        throw Error("E_DISCOVERY_MAP");
    const seen = new Set();
    for (const candidate of map["candidates"]) {
        if (!candidate || typeof candidate !== "object")
            throw Error("E_DISCOVERY_MAP");
        const row = candidate;
        if (Object.keys(row).sort().join() !== "market_id,selector,text" || typeof row["selector"] !== "string" ||
            !row["selector"] || row["selector"].length > 512 || seen.has(row["selector"]) ||
            row["text"] === null && row["market_id"] === null)
            throw Error("E_DISCOVERY_MAP");
        seen.add(row["selector"]);
        for (const key of ["text", "market_id"])
            if (row[key] !== null)
                text(row[key]);
    }
}
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const integer = /^(0|[1-9][0-9]{0,18})$/;
function counter(value) {
    if (typeof value !== "string" || !integer.test(value) || BigInt(value) > 9223372036854775807n)
        throw Error("E_CAPTURE_COUNTER");
    return BigInt(value);
}
function text(value) {
    if (typeof value !== "string" || !value || value.length > 256 || value !== value.normalize("NFC") ||
        Array.from(value).some(c => c.charCodeAt(0) < 32 || c.charCodeAt(0) === 127))
        throw Error("E_CAPTURE_TEXT");
    return value;
}
function validMarket(value) {
    if (!value || typeof value !== "object")
        return false;
    const m = value;
    if (m["settlement_basis"] !== "NORMAL_TIME_INCLUDING_STOPPAGE" || !m["labels"] || typeof m["labels"] !== "object")
        return false;
    const labels = m["labels"];
    if (Object.keys(labels).sort().join() !== "horizon,period,score_separator,status" ||
        ![null, "EN_DASH", "COLON", "HYPHEN"].includes(labels["score_separator"]))
        return false;
    text(labels["horizon"]);
    for (const [key, allowed] of [["status", ["OPEN", "SUSPENDED", "CLOSED", "UNKNOWN"]],
        ["period", ["PREGAME", "H1", "HALFTIME", "H2", "FINISHED", "BLOCKED", "OUT_OF_SCOPE", "UNKNOWN"]]]) {
        const map = labels[key];
        if (!map || typeof map !== "object")
            return false;
        const values = Object.values(map);
        if (Object.keys(map).some(k => !allowed.includes(k)) ||
            new Set(values).size !== values.length || values.some(v => !text(v)))
            return false;
    }
    return true;
}
export function validateCapturePlan(plan) {
    const url = new URL(plan.exactUrl);
    const synthetic = plan.sourceKind === "SYNTHETIC_TEST" && plan.profileStatus === "DRAFT" &&
        url.protocol === "http:" && url.hostname === "127.0.0.1";
    const real = plan.sourceKind === "OBSERVED_REAL" && plan.profileStatus === "ACCEPTED" && url.protocol === "https:";
    if ((!synthetic && !real) || url.username || url.password || url.search || url.hash ||
        !Number.isSafeInteger(plan.tabId) || plan.tabId < 0 ||
        !/^[0-9a-f]{64}$/.test(plan.profileHash) ||
        [plan.bindingId, plan.documentEpoch, plan.clockDomainId].some(id => !uuid.test(id)) ||
        !Number.isSafeInteger(plan.leaseMs) || plan.leaseMs <= 0 || plan.leaseMs > 7200000 ||
        !Number.isFinite(Date.parse(plan.expiresAt)) || Date.parse(plan.expiresAt) <= Date.now() ||
        !["DECIMAL_DOT", "DECIMAL_COMMA"].includes(plan.priceParser) ||
        plan.markets.length < 1 || plan.markets.length > 3 ||
        new Set(plan.markets.map(m => m.horizon)).size !== plan.markets.length ||
        !plan.markets.every(m => validMarket(m) &&
            ["H1", "H2", "FT"].includes(m.horizon) && Object.keys(m.selections).sort().join() === "AWAY,DRAW,HOME" &&
            new Set(Object.values(m.selections)).size === 3 && Object.values(m.selections).every(id => !!text(id))))
        throw Error("E_CAPTURE_PLAN");
    counter(plan.bindingRevision);
    counter(plan.captureRevision);
}
function raw(value) {
    if (!value || typeof value !== "object" || Object.keys(value).sort().join() !== [...rawFields].sort().join())
        throw Error("E_CAPTURE_FIELDS");
    for (const [name, v] of Object.entries(value))
        if (v !== null || !["score", "period"].includes(name))
            text(v);
    return value;
}
function mapped(value, mapping) {
    const matches = Object.entries(mapping).filter(([, label]) => label === value);
    const entry = matches[0];
    return matches.length === 1 && entry ? entry[0] : null;
}
export function assembleCapture(response, plan, challenge, revision) {
    if (!response || typeof response !== "object" || new TextEncoder().encode(JSON.stringify(response)).length > 65536)
        throw Error("E_CAPTURE_RESPONSE");
    const r = response;
    if (Object.keys(r).sort().join() !== ["status", "challenge", "first", "second", "firstReadMonoUs", "browserMonoUs", "observedAtUtc"].sort().join() ||
        r["status"] !== "DISPLAY_COHERENT" || r["challenge"] !== challenge || !/^[0-9a-f]{64}$/.test(challenge))
        throw Error("E_CAPTURE_RESPONSE");
    const first = raw(r["first"]), second = raw(r["second"]);
    if (rawFields.some(k => first[k] !== second[k]) || second["fixture_id"] !== plan.operatorFixtureId ||
        second["home_id"] !== plan.homeId || second["away_id"] !== plan.awayId)
        throw Error("E_CAPTURE_IDENTITY_OR_UNSTABLE");
    const interval = counter(r["browserMonoUs"]) - counter(r["firstReadMonoUs"]);
    if (interval < 100000n || interval > 1000000n || !Number.isFinite(Date.parse(text(r["observedAtUtc"]))))
        throw Error("E_CAPTURE_CLOCK");
    counter(revision);
    const matches = plan.markets.filter(m => m.market_id === second["market_root"] && m.labels.horizon === second["horizon_label"]);
    const market = matches[0];
    if (matches.length !== 1 || !market)
        throw Error("E_CAPTURE_MARKET");
    const selections = {};
    for (const side of ["HOME", "DRAW", "AWAY"]) {
        const key = side.toLowerCase();
        if (second[key + "_selection"] !== market.selections[side])
            throw Error("E_CAPTURE_SELECTION");
        const value = text(second[key + "_odds"]);
        const pattern = plan.priceParser === "DECIMAL_DOT" ? /^[1-9][0-9]{0,5}(\.[0-9]{1,6})?$/ : /^[1-9][0-9]{0,5}(,[0-9]{1,6})?$/;
        const odds = value.replace(",", ".");
        if (!pattern.test(value) || Number(odds) <= 1)
            throw Error("E_CAPTURE_PRICE");
        selections[side] = { selection_id: market.selections[side], decimal_odds: odds };
    }
    let score = null;
    const separator = market.labels.score_separator === "EN_DASH" ? "–" : market.labels.score_separator === "COLON" ? ":" : market.labels.score_separator === "HYPHEN" ? "-" : null;
    if (separator && second["score"]) {
        const parts = second["score"].split(separator);
        if (parts.length === 2 && parts.every(v => /^(0|[1-9][0-9]{0,2})$/.test(v))) {
            if (parts.some(v => Number(v) > 100))
                throw Error("E_CAPTURE_SCORE");
            score = { home: Number(parts[0]), away: Number(parts[1]) };
        }
    }
    return { binding_id: plan.bindingId, binding_revision: plan.bindingRevision, operator_fixture_id: plan.operatorFixtureId,
        market_id: market.market_id, horizon: market.horizon, settlement_basis: market.settlement_basis, selections,
        market_status: mapped(second["market_status"], market.labels.status) ?? "UNKNOWN", capture_revision: revision,
        native_revision: null, observed_at_utc: text(r["observedAtUtc"]), browser_mono_us: text(r["browserMonoUs"]),
        clock_domain_id: plan.clockDomainId, source_updated_at: null, operator_score: score,
        operator_period: mapped(second["period"], market.labels.period), capture_evidence_tier: "DISPLAY_COHERENT",
        profile_hash: plan.profileHash, document_epoch: plan.documentEpoch,
        quality_flags: plan.sourceKind === "SYNTHETIC_TEST" ? ["SYNTHETIC"] : [] };
}
export async function startReadOnlyCapture(input, callbacks, expectedDocumentId) {
    const plan = structuredClone(input);
    validateCapturePlan(plan);
    const tab = await chrome.tabs.get(plan.tabId);
    if (tab.url !== plan.exactUrl || !tab.active || tab.discarded)
        throw Error("E_CAPTURE_TAB");
    const results = await chrome.scripting.executeScript({ target: { tabId: plan.tabId, frameIds: [0] },
        files: ["src/live/dom_reader.js"], world: "ISOLATED" });
    if (results.length !== 1 || results[0]?.frameId !== 0 || !results[0].documentId)
        throw Error("E_CAPTURE_DOCUMENT");
    if (expectedDocumentId !== undefined && results[0].documentId !== expectedDocumentId)
        throw Error("E_CAPTURE_DOCUMENT_CHANGED");
    const identity = { tabId: plan.tabId, documentId: results[0].documentId,
        exactUrl: plan.exactUrl, captureId: crypto.randomUUID(), profileHash: plan.profileHash,
        bindingRevision: plan.bindingRevision, documentEpoch: plan.documentEpoch };
    let stopped = false, revision = counter(plan.captureRevision);
    const isStopped = () => stopped;
    const send = (operation, value) => chrome.tabs.sendMessage(plan.tabId, { kind: "FIXED_DOM_READONLY", operation, value }, { documentId: identity.documentId });
    const stop = async () => {
        if (stopped)
            return;
        stopped = true;
        chrome.runtime.onMessage.removeListener(listener);
        chrome.tabs.onRemoved.removeListener(removed);
        chrome.tabs.onUpdated.removeListener(updated);
        await send("STOP", identity.captureId).catch(() => undefined);
    };
    const listener = (message, sender) => {
        if (stopped || !handleCaptureMessage(message, sender, identity, chrome.runtime.id))
            return;
        const code = message.code;
        if (code === "RECAPTURE")
            callbacks.onRecapture();
        else {
            callbacks.onInvalidation(code);
            if (["NAVIGATED", "HIDDEN", "PROFILE_EXPIRED"].includes(code))
                void stop();
        }
    };
    const removed = (tabId) => { if (tabId === plan.tabId) {
        callbacks.onInvalidation("NAVIGATED");
        void stop();
    } };
    const updated = (tabId, change) => {
        if (tabId === plan.tabId && (change.discarded === true || change.status === "loading" || (change.url !== undefined && change.url !== plan.exactUrl)))
            removed(tabId);
    };
    chrome.runtime.onMessage.addListener(listener);
    chrome.tabs.onRemoved.addListener(removed);
    chrome.tabs.onUpdated.addListener(updated);
    try {
        const ready = await send("INIT", { captureId: identity.captureId, profileHash: plan.profileHash,
            bindingRevision: plan.bindingRevision, documentEpoch: plan.documentEpoch, exactUrl: plan.exactUrl,
            leaseMs: Math.min(plan.leaseMs, Date.parse(plan.expiresAt) - Date.now()), selectors: plan.selectors });
        if (!ready || ready.status !== "READY")
            throw Error("E_CAPTURE_INIT");
    }
    catch {
        await stop();
        throw Error("E_CAPTURE_INIT");
    }
    return { identity, stop, request: async (challenge) => {
            if (stopped)
                throw Error("E_CAPTURE_STOPPED");
            try {
                const response = await send("READ", challenge);
                if (isStopped())
                    throw Error();
                const book = assembleCapture(response, plan, challenge, String(revision + 1n));
                revision++;
                await callbacks.onBook(book, challenge);
            }
            catch {
                callbacks.onInvalidation("DOM_UNSTABLE");
            }
        } };
}
