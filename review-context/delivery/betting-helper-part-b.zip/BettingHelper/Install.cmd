@echo off
"C:\Users\thenam\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" -I -B "%~dp0launch_part_b.py" --install
pause
