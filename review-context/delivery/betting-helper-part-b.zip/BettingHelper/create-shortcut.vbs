Set shell = CreateObject("WScript.Shell")
Set link = shell.CreateShortcut(WScript.Arguments(0))
link.TargetPath = WScript.Arguments(1)
link.Arguments = "-I -B " & Chr(34) & WScript.Arguments(2) & Chr(34)
link.WorkingDirectory = WScript.Arguments(3)
link.Description = "Betting Helper - read only"
link.Save
